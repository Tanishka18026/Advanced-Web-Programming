﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Web.UI;
using System.Linq;



namespace ClothingStore
{
    public partial class ProductDisplay : System.Web.UI.Page
    {
        string connectionString = ConfigurationManager.ConnectionStrings["ThriftDBConnection"].ConnectionString;


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

               
                    // Automatically trigger the Browse_Click logic during initial page load
                    ProductsGrid.Visible = true;
                    CartGrid.Visible = false;
                    BtnLogout.Visible = false;
                    btnProceedToBuy.Visible = false;
                    PaymentMode.Visible = false;
                    AddressForm.Visible = false;
                    LoadProducts();
                
                
            }
            
        }
 


        protected void Browse_Click(object sender, EventArgs e)
        {
            ProductsGrid.Visible = true;
            CartGrid.Visible = false;
            BtnLogout.Visible = false;
            btnProceedToBuy.Visible = false;
            PaymentMode.Visible = false;
            AddressForm.Visible = false;
            LoadProducts();
        }
        private void LoadProducts()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT ProductID, ProductName, Category, Price, SizeOptions, StockQuantity FROM Products WHERE StockQuantity > 0";
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                ProductsGrid.DataSource = dt;
                ProductsGrid.DataBind();
            }
        }



        protected void AddToCart(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "AddToCart")
            {
                if (Session["Username"] == null)
                {
                    // Show the login modal dialog
                    ScriptManager.RegisterStartupScript(this, GetType(), "showLoginModal", "showLoginModal();", true);
                    return;
                }
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = ProductsGrid.Rows[rowIndex];

                // Adjusted column indexes based on the new order
                int productId = Convert.ToInt32(row.Cells[0].Text); // Product ID is in the first column
                string productName = row.Cells[2].Text; // Product Name is in the third column
                string category = row.Cells[3].Text; // Category is in the fourth column

                // Price is in the fifth column
                string priceText = row.Cells[4].Text.Trim();

                // Remove currency symbols and commas
                priceText = priceText.Replace("₹", "").Replace("$", "").Replace(",", "");
                decimal price;
                if (Decimal.TryParse(priceText, out price))
                {
                    // Get the selected size from DropDownList
                    DropDownList sizeDropDown = (DropDownList)row.FindControl("SizeDropDown");
                    string selectedSize = sizeDropDown.SelectedItem.Text;

                    // Get the quantity from the TextBox
                    TextBox txtQuantity = (TextBox)row.FindControl("txtQuantity");
                    int quantity = 1; // Default to 1 if not valid
                    if (txtQuantity != null && int.TryParse(txtQuantity.Text, out quantity) && quantity > 0)
                    {
                        // Check the available stock quantity for the product
                        int availableStock = GetProductStockQuantity(productId);

                        if (quantity <= availableStock)
                        {
                            // If the quantity is less than or equal to stock, add to cart
                            AddProductToCart(productId, productName, category, price, selectedSize, quantity);
                        }
                        else
                        {
                            // If the quantity exceeds stock, display an error message in modal
                            string errorMessage = "Insufficient stock available. Only " + availableStock + " items are in stock.";
                            ScriptManager.RegisterStartupScript(this, GetType(), "showErrorModal", "showErrorModal('" + errorMessage + "');", true);
                        }
                    }
                    else
                    {
                        string errorMessage = "Please enter a valid quantity.";
                        ScriptManager.RegisterStartupScript(this, GetType(), "showErrorModal", "showErrorModal('" + errorMessage + "');", true);
                    }
                }
                else
                {
                    // Log the problematic price and display an error message in modal
                    string errorMessage = "Invalid price format: " + priceText;
                    ScriptManager.RegisterStartupScript(this, GetType(), "showErrorModal", "showErrorModal('" + errorMessage + "');", true);
                }
            }
        }
        private int GetProductStockQuantity(int productId)
        {
            int stockQuantity = 0;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT StockQuantity FROM Products WHERE ProductID = @ProductID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ProductID", productId);

                    conn.Open();
                    object result = cmd.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        stockQuantity = Convert.ToInt32(result);
                    }
                }
            }

            return stockQuantity;
        }



        private void AddProductToCart(int productId, string productName, string category, decimal price, string size, int quantity)
        {
            string username = Session["Username"] as string; // Retrieve the username from session

            if (string.IsNullOrEmpty(username))
            {
                // If no username is found, redirect to login page
                Response.Redirect("WebForm1.aspx");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Cart (ProductID, ProductName, Category, Price, Size, Quantity, Username) " +
                               "VALUES (@ProductID, @ProductName, @Category, @Price, @Size, @Quantity, @Username)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@ProductID", productId);
                    cmd.Parameters.AddWithValue("@ProductName", productName);
                    cmd.Parameters.AddWithValue("@Category", category);
                    cmd.Parameters.AddWithValue("@Price", price);
                    cmd.Parameters.AddWithValue("@Size", size);
                    cmd.Parameters.AddWithValue("@Quantity", quantity);
                    cmd.Parameters.AddWithValue("@Username", username); // Add the Username to the query

                    conn.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // Display success dialog
                        ScriptManager.RegisterStartupScript(this, GetType(), "ProductAdded",
                            "showSuccessModal('Product successfully added to the cart!');", true);
                    }
                    else
                    {
                        // Display failure dialog
                        ScriptManager.RegisterStartupScript(this, GetType(), "ProductNotAdded",
                            "showSuccessModal('Failed to add product to the cart.');", true);
                    }

                }
            }
        }









        // This method is used to dynamically bind the size options to the DropDownList
        protected void ProductsGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Set the product image based on ProductID
                int productId = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "ProductID"));
                Image imgProduct = (Image)e.Row.FindControl("imgProduct");
                imgProduct.ImageUrl = "~/Images/P" + productId.ToString("D3") + ".jpg";

                // Bind the DropDownList with size options
                DropDownList sizeDropDown = (DropDownList)e.Row.FindControl("SizeDropDown");
                string sizeOptions = DataBinder.Eval(e.Row.DataItem, "SizeOptions").ToString();
                string[] sizes = sizeOptions.Split(',');

                sizeDropDown.DataSource = sizes;
                sizeDropDown.DataBind();
            }
        }

        protected void Cart_Click(object sender, EventArgs e)
        {
            ProductsGrid.Visible = false;  // Hide the grid of products
            CartGrid.Visible = true;
          //  btnProceedToBuy.Visible = true;
            BtnLogout.Visible = false;
            PaymentMode.Visible = false;
            AddressForm.Visible = false;
            // Call the method to load cart items based on the logged-in user's username
            LoadCartItems();
        }

        protected void LoadCartItems()
        {
            if (Session["Username"] == null)
            {
                // Show the login modal dialog
                ScriptManager.RegisterStartupScript(this, GetType(), "showLoginModal", "showLoginModal();", true);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT CartID, ProductID, ProductName, Category, Price, Size, Quantity FROM Cart WHERE Username = @Username";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Username", Session["Username"]);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count > 0) // Check if cart has items
                {
                    // Recalculate total price
                    decimal totalPrice = 0m;
                    foreach (DataRow row in dt.Rows)
                    {
                        decimal price = Convert.ToDecimal(row["Price"]);
                        int quantity = Convert.ToInt32(row["Quantity"]);
                        totalPrice += price * quantity;
                    }

                    // Store total price in ViewState
                    ViewState["TotalPrice"] = totalPrice;

                    // Bind data to CartGrid and show it
                    CartGrid.Visible = true;
                    CartGrid.DataSource = dt;
                    CartGrid.DataBind();

                    // Show "Proceed to Buy" button
                    btnProceedToBuy.Visible = true;
                }
                else
                {
                    // If the cart is empty, display a message and hide relevant controls
                    CartGrid.Visible = false;
                    btnProceedToBuy.Visible = false;

                    // Clear previous controls and display an empty cart message
                    ProductContainer.Controls.Clear();
                    Label lblNoItems = new Label();
                    lblNoItems.Text = "Your cart is empty.";
                    lblNoItems.CssClass = "empty-cart-message"; // Optional: CSS styling
                    ProductContainer.Controls.Add(lblNoItems);
                }
            }
        }



        protected void CartGrid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Remove")
            {
                // Get the ProductID (or CartID) from the CommandArgument
                string cartId = e.CommandArgument.ToString();

                string username = Session["Username"] as string;
                if (string.IsNullOrEmpty(username))
                {
                    // Redirect to login page if the session has expired
                    Response.Redirect("WebForm1.aspx");
                    return;
                }

                // Remove the product from the database for the current user
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string deleteQuery = "DELETE FROM Cart WHERE CartID = @CartID AND Username = @Username";
                    SqlCommand cmd = new SqlCommand(deleteQuery, conn);
                    cmd.Parameters.AddWithValue("@CartID", cartId);
                    cmd.Parameters.AddWithValue("@Username", username);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }

                // Reload the cart items after deletion
                LoadCartItems();  // This method will refresh the GridView
            }
        }



        protected void CartGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            // Reset TotalPrice to 0 only during the header row binding
            if (e.Row.RowType == DataControlRowType.Header)
            {
                ViewState["TotalPrice"] = 0m; // Reset total price
            }

            // Check if the row is a data row (not header or footer)
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Get price and quantity from the current row
                decimal price = Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "Price"));
                int quantity = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "Quantity"));

                // Calculate subtotal for this row
                decimal subtotal = price * quantity;

                // Add this row's subtotal to the total price
                ViewState["TotalPrice"] = (decimal)ViewState["TotalPrice"] + subtotal;
            }
            else if (e.Row.RowType == DataControlRowType.Footer)
            {
                // Display the total price in the footer
                e.Row.Cells[0].Text = "Total:";  // Label for the total
                e.Row.Cells[0].ColumnSpan = 4;   // Adjust column span
                e.Row.Cells[0].HorizontalAlign = HorizontalAlign.Right;

                // Remove any unwanted cells (e.g., adjust for correct column count)
                e.Row.Cells.RemoveAt(1);

                // Display the total price formatted as currency
                e.Row.Cells[1].Text = ((decimal)ViewState["TotalPrice"]).ToString("C");
            }
        }







        protected void SubmitAddress_Click(object sender, EventArgs e)
        {
            // Validate the address form inputs
            string addressLine = txtAddressLine.Text.Trim();
            string city = txtCity.Text.Trim();
            string state = txtState.Text.Trim();
            string postalCode = txtPostalCode.Text.Trim();

            if (string.IsNullOrEmpty(addressLine) || string.IsNullOrEmpty(city) ||
                string.IsNullOrEmpty(state) || string.IsNullOrEmpty(postalCode))
            {
                lblAddressError.Text = "All fields are required. Please complete your address.";
                lblAddressError.Visible = true;
                return;
            }

            if (postalCode.Length != 6 || !postalCode.All(char.IsDigit))
            {
                lblAddressError.Text = "Please enter a valid 6-digit postal code.";
                lblAddressError.Visible = true;
                return;
            }

            // If validation passes, proceed to payment mode
            AddressForm.Visible = true;
            
        }


        protected void ProceedToBuy_Click(object sender, EventArgs e)
        {
            // Reset payment-related controls
            lblMessage.Text = string.Empty; // Clear any existing message
            lblMessage.Visible = false;    // Hide the label
            rdoCardPayment.Checked = false; // Reset radio button selection
            rdoCashOnDelivery.Checked = false; // Reset radio button selection
            CardPaymentDetails.Visible = false; // Hide card payment details section

            // Get total products and total amount from ViewState
            int totalProducts = CartGrid.Rows.Count;
            decimal totalAmount = ViewState["TotalPrice"] != null ? (decimal)ViewState["TotalPrice"] : 0;

            // Save the order details in the Order table
            string username = Session["Username"] as string;
            if (string.IsNullOrEmpty(username))
            {
                Response.Redirect("WebForm1.aspx");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string insertOrderQuery = "INSERT INTO [Order] (Username, TotalProducts, TotalAmount, Date) " +
                                          "VALUES (@Username, @TotalProducts, @TotalAmount, @Date)";
                SqlCommand cmd = new SqlCommand(insertOrderQuery, conn);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@TotalProducts", totalProducts);
                cmd.Parameters.AddWithValue("@TotalAmount", totalAmount);
                cmd.Parameters.AddWithValue("@Date", DateTime.Now); // Add the current date and time

                conn.Open();
                cmd.ExecuteNonQuery();
            }

            // Display payment options
            AddressForm.Visible = true;
            PaymentMode.Visible = true;
            CartGrid.Visible = false;
            btnProceedToBuy.Visible = false;
            ProductsGrid.Visible = false;
            BtnLogout.Visible = false;
        }


        protected void PaymentMode_Changed(object sender, EventArgs e)
        {
            if (rdoCardPayment.Checked)
            {
                CardPaymentDetails.Visible = true; // Show card payment fields
            }
            else
            {
                CardPaymentDetails.Visible = false; // Hide card payment fields
            }
        }

        protected void ConfirmPayment_Click(object sender, EventArgs e)
        {
            // Hide error messages at the start of the click
            lblAddressError.Visible = false;
            lblMessage.Visible = false;

            // Validate Address Form Inputs
            string addressLine = txtAddressLine.Text.Trim();
            string city = txtCity.Text.Trim();
            string state = txtState.Text.Trim();
            string postalCode = txtPostalCode.Text.Trim();

            if (string.IsNullOrEmpty(addressLine) || string.IsNullOrEmpty(city) ||
                string.IsNullOrEmpty(state) || string.IsNullOrEmpty(postalCode))
            {
                lblAddressError.Text = "All fields are required. Please complete your address.";
                lblAddressError.Visible = true;
                return;
            }

            if (postalCode.Length != 6 || !postalCode.All(char.IsDigit))
            {
                lblAddressError.Text = "Please enter a valid 6-digit postal code.";
                lblAddressError.Visible = true;
                return;
            }

            // Validate Payment Mode Selection
            if (!rdoCashOnDelivery.Checked && !rdoCardPayment.Checked)
            {
                lblMessage.Text = "Please select a payment mode.";
                lblMessage.Visible = true;
                return;
            }

            if (rdoCardPayment.Checked)
            {
                string accountNumber = txtAccountNumber.Text.Trim();
                string pin = txtPin.Text.Trim();

                // Validate Card Payment Fields
                if (accountNumber.Length != 14 || pin.Length != 4)
                {
                    lblMessage.Text = "Invalid account number or PIN.";
                    lblMessage.Visible = true;
                    return;
                }
            }

            // Get total products and total amount from ViewState
            int totalProducts = CartGrid.Rows.Count;
            decimal totalAmount = ViewState["TotalPrice"] != null ? (decimal)ViewState["TotalPrice"] : 0;

            // Proceed with the payment
            if (rdoCashOnDelivery.Checked)
            {
                lblMessage.Text = "Order confirmed! Your items will be delivered soon.";
            }
            else
            {
                lblMessage.Text = "Payment successful! Your items will be delivered soon.";
            }

            lblMessage.Visible = true;

            // Clear cart after successful payment
            ClearCart();

            // Hide the Address Form and Payment Options
            AddressForm.Visible = false;
            PaymentMode.Visible = false;
        }

        private void ClearCart()
        {
            string username = Session["Username"] as string;
            if (!string.IsNullOrEmpty(username))
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string deleteCartQuery = "DELETE FROM Cart WHERE Username = @Username";
                    SqlCommand cmd = new SqlCommand(deleteCartQuery, conn);
                    cmd.Parameters.AddWithValue("@Username", username);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }


      


        protected void Order_Click(object sender, EventArgs e)
        {
            if (Session["Username"] == null)
            {
                // Show the login modal dialog
                ScriptManager.RegisterStartupScript(this, GetType(), "showLoginModal", "showLoginModal();", true);
                return;
            }
            string username = Session["Username"] as string; // Get the logged-in user's username
            
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                // Corrected the table name to 'Order'
                string query = "SELECT OrderID, TotalProducts, TotalAmount, Date " +
                               "FROM [Order] WHERE Username = @Username ORDER BY Date ASC";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Username", username);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Clear the panel before adding new data
                OrderHistoryPanel.Controls.Clear();

                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        // Create a new panel for each order
                        Panel orderPanel = new Panel();
                        orderPanel.CssClass = "order-panel";

                        // Order ID
                        Label lblOrderID = new Label();
                        lblOrderID.Text = "<strong>Order ID:</strong> " + row["OrderID"].ToString() + "<br />";
                        orderPanel.Controls.Add(lblOrderID);

                        // Total Products
                        Label lblTotalProducts = new Label();
                        lblTotalProducts.Text = "<strong>Total Products:</strong> " + row["TotalProducts"].ToString() + "<br />";
                        orderPanel.Controls.Add(lblTotalProducts);

                        // Total Amount
                        Label lblTotalAmount = new Label();
                        lblTotalAmount.Text = "<strong>Total Amount:</strong> " + Convert.ToDecimal(row["TotalAmount"]).ToString("C") + "<br />";
                        orderPanel.Controls.Add(lblTotalAmount);

                        // Date
                        Label lblDate = new Label();
                        lblDate.Text = "<strong>Date:</strong> " + Convert.ToDateTime(row["Date"]).ToString("yyyy-MM-dd HH:mm") + "<br />";
                        orderPanel.Controls.Add(lblDate);

                        // Separator
                        Literal separator = new Literal();
                        separator.Text = "<hr />";
                        orderPanel.Controls.Add(separator);

                        // Add the order panel to the main panel
                        OrderHistoryPanel.Controls.Add(orderPanel);
                    }
                }
                else
                {
                    // Display a message if no orders are found
                    Label lblNoOrders = new Label();
                    lblNoOrders.Text = "No order history found.";
                    OrderHistoryPanel.Controls.Add(lblNoOrders);
                }
            }
            ProductsGrid.Visible = false;
            btnProceedToBuy.Visible = false;
            BtnLogout.Visible = false;
            PaymentMode.Visible = false;
            CartGrid.Visible = false;
            AddressForm.Visible = false;
        }



        protected void Users_Click(object sender, EventArgs e)
        {
            if (Session["Username"] == null)
            {
                // Show the login modal dialog
                ScriptManager.RegisterStartupScript(this, GetType(), "showLoginModal", "showLoginModal();", true);
                return;
            }
            string username = Session["Username"] as string; // Get the logged-in user's username

           
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT UserID, UserName, Email FROM Users WHERE UserName = @Username";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Username", username);

                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    reader.Read(); // Read the first row (should be only one)

                    // Display user information
                    Label lblUserID = new Label();
                    lblUserID.Text = "<strong>User ID:</strong> " + reader["UserID"].ToString() + "<br />";
                    UserPanel.Controls.Add(lblUserID); // Assuming UserPanel is a PlaceHolder or Panel for displaying user info

                    Label lblUserName = new Label();
                    lblUserName.Text = "<strong>User Name:</strong> " + reader["UserName"].ToString() + "<br />";
                    UserPanel.Controls.Add(lblUserName);

                    Label lblEmail = new Label();
                    lblEmail.Text = "<strong>Email:</strong> " + reader["Email"].ToString() + "<br />";
                    UserPanel.Controls.Add(lblEmail);

                    // Add a login button

                  
                }
                else
                {
                    // If no user found, display a message
                    Label lblNoUser = new Label();
                    lblNoUser.Text = "No user found.";
                    UserPanel.Controls.Add(lblNoUser);
                }
                reader.Close();
            }
            btnProceedToBuy.Visible = false;
            ProductsGrid.Visible = false;
            BtnLogout.Visible = true;
            AddressForm.Visible = false;
            PaymentMode.Visible = false;
            CartGrid.Visible = false;
        }

        protected void BtnLogout_Click(object sender, EventArgs e)
        {
            // Clear the session
            Session.Clear();
            Session.Abandon();

            // Redirect to the login page
            Response.Redirect("WebForm1.aspx", true);
        }





        
    }
}