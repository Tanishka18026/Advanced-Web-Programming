﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;


namespace ClothingStore
{
    public partial class WebForm1 : Page
    {
        public static string connectionString = ConfigurationManager.ConnectionStrings["ThriftDBConnection"].ConnectionString;

        private SqlConnection connection = new SqlConnection(connectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            AddCssStyles(); // Add the CSS dynamically
            if (!IsPostBack)
            {
                DisplayMainMenu();
            }
            else
            {
                // Recreate controls based on the current view stored in ViewState
                string currentView = ViewState["CurrentView"] as string;
                if (currentView == "LoginForm")
                {
                    ShowLoginForm();
                }
                else if (currentView == "RegisterForm")
                {
                    ShowRegisterForm();
                }
                else
                {
                    DisplayMainMenu(); // Default to MainPage if no valid view is found
                }
            }
        }

        private void AddCssStyles()
        {
            Literal css = new Literal
            {
                Text = @"
            <style>
                body {
                    font-family: Arial, sans-serif;
                    text-align: center;
                    margin: 0;
                    padding: 0;
                    background-color: #f4f4f9;
                    color: #333;
                }
                h1, h2 {
                    color: #333;
                }
                form {
                    display: inline-block;
                    margin-top: 20px;
                    text-align: left;
                    padding: 90px;
                    border: 1px solid #ccc;
                    background-color: #fff;
                    border-radius: 8px;
                    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
                    width: 100%; /* Make form take full width */
                    max-width: 500px; /* Set a maximum width for the form */
                }
                input[type='text'], input[type='password'] {
                    width: 100%;
                    padding: 10px;
                    margin: 10px 0;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                }
                button, input[type='submit'], input[type='button'] {
                    display: inline-block;
                    margin: 10px 5px;
                    padding: 10px 20px;
                    background-color: #007bff;
                    color: #fff;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    transition: transform 0.2s, box-shadow 0.2s;
                }
                button:hover, input[type='submit']:hover, input[type='button']:hover {
                    background-color: #0056b3;
                    transform: scale(1.1);
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                }
                button:focus, input[type='submit']:focus, input[type='button']:focus {
                    outline: none;
                }
                /* Additional styles for the label */
                .header-label {
    font-size: 36px; /* Big font size */
    color: blue;     /* Blue color */
    font-weight: bold;
    font-style: italic; /* Italic text */
    display: block;
    margin-bottom: 20px; /* Space below the label */
    text-align: center;  /* Center the text horizontally */
    margin-left: auto;   /* Center the block element horizontally */
    margin-right: auto;  /* Center the block element horizontally */
}
                /* Centering the buttons */
                .button-container {
                    text-align: center;
                    margin-top: 20px;
                }
            </style>"
            };
            Page.Header.Controls.Add(css); // Add CSS to the page header
        }



        // Display Main Menu with Login and Register buttons
        private void DisplayMainMenu()
        {
            ViewState["CurrentView"] = "MainMenu"; // Set current view

            form1.Controls.Clear(); // Clear any existing controls

            // Create and style the label with the CSS class
            Label lblHeader = new Label();
            lblHeader.Text = "T's THRIFT STORE";
            lblHeader.CssClass = "header-label"; // Apply the CSS class

            // Add the label to the form
            form1.Controls.Add(lblHeader);

            // Add some space after the label
            form1.Controls.Add(new Literal { Text = "<br /><br />" });

            // Create a container for buttons to center them
            HtmlGenericControl buttonContainer = new HtmlGenericControl("div");
            buttonContainer.Attributes["class"] = "button-container";

            ShowLoginForm();
            

            
            // Add the button container to the form
            form1.Controls.Add(buttonContainer);
        }



        private void ShowLoginForm()
        {
            ViewState["CurrentView"] = "LoginForm"; // Set current view

            form1.Controls.Clear(); // Clear existing controls
            form1.Controls.Add(new Literal { Text = "<h2>Login</h2>" });

            // Username TextBox
            form1.Controls.Add(new Literal { Text = "Username: " });
            TextBox txtUsername = new TextBox { ID = "txtUsername" };
            form1.Controls.Add(txtUsername);
            form1.Controls.Add(new Literal { Text = "<br />" });

            // Password TextBox
            form1.Controls.Add(new Literal { Text = "Password: " });
            TextBox txtPassword = new TextBox { ID = "txtPassword", TextMode = TextBoxMode.Password };
            form1.Controls.Add(txtPassword);
            form1.Controls.Add(new Literal { Text = "<br />" });

            // Login Button
            Button btnLogin = new Button { ID = "btnLogin", Text = "Login" };
            btnLogin.Click += btnLogin_Click;
            form1.Controls.Add(btnLogin);

            // Message Label
            Label lblMessage = new Label { ID = "lblMessage", ForeColor = System.Drawing.Color.Red };
            lblMessage.Text = ""; // Ensure it starts empty
            form1.Controls.Add(new Literal { Text = "<br />" }); // Space between elements
            form1.Controls.Add(lblMessage);

            
            // Back Button to return to Main Menu
             LinkButton btnShowRegister = new LinkButton { ID = "btnShowRegister", Text = "Don't have an account?Click here to register" };
            btnShowRegister.Click += (s, e) => ShowRegisterForm();
            form1.Controls.Add(new Literal { Text = "<br />" }); // Add a line break before the button
            form1.Controls.Add(btnShowRegister);
        }

        private void ShowRegisterForm()
        {
            ViewState["CurrentView"] = "RegisterForm"; // Set current view

            form1.Controls.Clear(); // Clear existing controls
            form1.Controls.Add(new Literal { Text = "<h2>Register</h2>" });

            // Username TextBox
            form1.Controls.Add(new Literal { Text = "Username: " });
            TextBox txtNewUsername = new TextBox { ID = "txtNewUsername" };
            form1.Controls.Add(txtNewUsername);
            form1.Controls.Add(new Literal { Text = "<br />" });

            // Password TextBox
            form1.Controls.Add(new Literal { Text = "Password: " });
            TextBox txtNewPassword = new TextBox { ID = "txtNewPassword", TextMode = TextBoxMode.Password };
            form1.Controls.Add(txtNewPassword);
            form1.Controls.Add(new Literal { Text = "<br />" });

            // Confirm Password TextBox
            form1.Controls.Add(new Literal { Text = "Confirm Password: " });
            TextBox txtConfirmPassword = new TextBox { ID = "txtConfirmPassword", TextMode = TextBoxMode.Password };
            form1.Controls.Add(txtConfirmPassword);
            form1.Controls.Add(new Literal { Text = "<br />" });

            // Email TextBox
            form1.Controls.Add(new Literal { Text = "Email: " });
            TextBox txtEmail = new TextBox { ID = "txtEmail" };
            form1.Controls.Add(txtEmail);
            form1.Controls.Add(new Literal { Text = "<br />" });

            // Register Button
            Button btnRegister = new Button { ID = "btnRegister", Text = "Register" };
            btnRegister.Click += btnRegister_Click;
            form1.Controls.Add(btnRegister);

            // Message Label
            Label lblRegisterMessage = new Label { ID = "lblRegisterMessage", ForeColor = System.Drawing.Color.Red };
            lblRegisterMessage.Text = ""; // Ensure it starts empty
            form1.Controls.Add(new Literal { Text = "<br />" }); // Space between elements
            form1.Controls.Add(lblRegisterMessage);

            // Back Button to return to Main Menu
            Button btnBackToMainMenu = new Button { ID = "btnBackToMainMenu", Text = "Back to Login" };
            btnBackToMainMenu.Click += (s, e) => DisplayMainMenu();
            form1.Controls.Add(new Literal { Text = "<br />" }); // Add a line break before the button
            form1.Controls.Add(btnBackToMainMenu);
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = ((TextBox)form1.FindControl("txtUsername")).Text;
            string password = ((TextBox)form1.FindControl("txtPassword")).Text;

            // Check if username or password are empty or only whitespace
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                ((Label)form1.FindControl("lblMessage")).Text = "Username and password cannot be empty.";
                return;
            }

            string query = "SELECT * FROM Users WHERE Username=@Username AND Password=@Password";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password", password);

            connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                Session["Username"] = username;
                connection.Close(); // Close connection before redirecting
                Response.Redirect("ProductDisplay.aspx"); // Redirect to ProductDisplay.aspx
            }
            else
            {
                ((Label)form1.FindControl("lblMessage")).Text = "Invalid username or password.";
                connection.Close();
            }
        }


        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string username = ((TextBox)form1.FindControl("txtNewUsername")).Text;
            string password = ((TextBox)form1.FindControl("txtNewPassword")).Text;
            string confirmPassword = ((TextBox)form1.FindControl("txtConfirmPassword")).Text;
            string email = ((TextBox)form1.FindControl("txtEmail")).Text;

            // Check if username, password, and email are empty or only whitespace
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(confirmPassword) || string.IsNullOrWhiteSpace(email))
            {
                ((Label)form1.FindControl("lblRegisterMessage")).Text = "All fields are required.";
                return;
            }

            if (password != confirmPassword)
            {
                ((Label)form1.FindControl("lblRegisterMessage")).Text = "Passwords do not match.";
                return;
            }

            string query = "INSERT INTO Users (Username, Password, Email) VALUES (@Username, @Password, @Email)";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@Username", username);
            cmd.Parameters.AddWithValue("@Password", password);
            cmd.Parameters.AddWithValue("@Email", email);

            connection.Open();
            try
            {
                cmd.ExecuteNonQuery();
                ((Label)form1.FindControl("lblRegisterMessage")).Text = "Registration successful!";
                DisplayMainMenu(); // Redirect to main menu after registration
            }
            catch (SqlException)
            {
                ((Label)form1.FindControl("lblRegisterMessage")).Text = "Username or Email already exists.";
            }
            finally
            {
                connection.Close();
            }
        }

    }
}
