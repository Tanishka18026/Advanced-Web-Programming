﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace BankApplication
{
    public partial class BankApp : System.Web.UI.Page
    {
        public class BankAccount
        {
            public string AccountHolderName { get; set; }
            public long AccountNumber { get; set; }
            public string AccountType { get; set; }
            public double AccountBalance { get; set; }
            public string PinNumber { get; set; }
        }

        private List<BankAccount> Accounts
        {
            get
            {
                if (Session["Accounts"] == null)
                {
                    Session["Accounts"] = new List<BankAccount>();
                }
                return (List<BankAccount>)Session["Accounts"];
            }
            set
            {
                Session["Accounts"] = value;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Display the main menu on the initial page load
                DisplayMainMenu();
            }
            else
            {
                // Recreate controls based on the current view stored in ViewState
                string currentView = ViewState["CurrentView"] as string;

                if (currentView == "BankerMenu")
                {
                    DisplayBankerMenu();
                }
                else if (currentView == "CustomerMenu")
                {
                    DisplayCustomerLogin();
                }
                else if (currentView == "CreateAccountForm")
                {
                    CreateAccountForm();
                }
                else if (currentView == "RemoveAccountForm") // Ensure this matches the view you set
                {
                    RemoveAccount(); // This will call your RemoveAccount method and re-add the controls
                }
                else if (currentView == "CustomerDashboard")
                {
                    DisplayCustomerDashboard();
                }
                else if (currentView == "WithdrawForm")
                {
                    WithdrawAmount();
                }
                else if (currentView == "DepositForm")
                {
                    DepositAmount();
                }
                else
                {
                    DisplayMainMenu();
                }
            }
        }



        private void DisplayMainMenu()
        {
            ViewState["CurrentView"] = "MainMenu";
            MainMenu.Controls.Clear();
            MainMenu.Visible = true;
            BankerMenu.Visible = false;
            CustomerMenu.Visible = false;

            var lblTitle = new Label { Text = "<h2>Welcome to Bank Management System</h2>", CssClass = "title" };
            MainMenu.Controls.Add(lblTitle);

            var btnBanker = new Button { Text = "Banker", ID = "btnBanker", CssClass = "btn" };
            btnBanker.Click += (s, e) => DisplayBankerMenu();
            MainMenu.Controls.Add(btnBanker);


            var btnCustomer = new Button { Text = "Customer", ID = "btnCustomer", CssClass = "btn" };
            btnCustomer.Click += (s, e) => DisplayCustomerLogin();
            MainMenu.Controls.Add(btnCustomer);

            var btnExit = new Button { Text = "Exit", ID = "btnExit", CssClass = "btn" };
            btnExit.Click += (s, e) => ExitApplication();
            MainMenu.Controls.Add(btnExit);

            // Wrap all controls in a container div
            var container = new Panel { CssClass = "container" };
            container.Controls.Add(lblTitle);
            container.Controls.Add(btnBanker);
            container.Controls.Add(btnCustomer);
            container.Controls.Add(btnExit);
            MainMenu.Controls.Add(container);
        }


        private void DisplayBankerMenu()
        {
            ViewState["CurrentView"] = "BankerMenu";
            MainMenu.Visible = false;
            BankerMenu.Visible = true;
            CustomerMenu.Visible = false;

            BankerMenu.Controls.Clear();

            // Create container for the banker menu
            var container = new Panel { CssClass = "banker-menu-container" };

            var lblTitle = new Label { Text = "<h3>Banker Menu</h3>", EnableViewState = false, CssClass = "title" };
            container.Controls.Add(lblTitle);

            var btnCreate = new Button { Text = "Create Account", ID = "btnCreate", CssClass = "btn" };
            btnCreate.Click += (s, e) => CreateAccountForm();
            container.Controls.Add(btnCreate);

            var btnViewAll = new Button { Text = "View All Accounts", ID = "btnViewAll", CssClass = "btn" };
            btnViewAll.Click += (s, e) => DisplayAllAccounts();
            container.Controls.Add(btnViewAll);

            var btnRemoveAccount = new Button { Text = "Remove Account", ID = "btnRemoveAccount", CssClass = "btn" };
            btnRemoveAccount.Click += (s, e) => RemoveAccount();
            container.Controls.Add(btnRemoveAccount);

            var btnBack = new Button { Text = "Back to Main Menu", ID = "btnBack", CssClass = "btn" };
            // This button goes to the main menu
            btnBack.Click += (s, e) => DisplayMainMenu();
            container.Controls.Add(btnBack);

            // Add container to the BankerMenu
            BankerMenu.Controls.Add(container);
        }



        private void CreateAccountForm()
        {
            ViewState["CurrentView"] = "CreateAccountForm";
            BankerMenu.Controls.Clear();
            var container = new Panel { CssClass = "form-container-left" };


            var lblTitle = new Label { Text = "<h3>Create Account</h3>", EnableViewState = false, CssClass = "title" };
            // Account Holder Name
            var lblName = new Label { Text = "Account Holder Name: " };
            var txtName = new TextBox { ID = "txtName", MaxLength = 30 };
            var lblNameError = new Label { ID = "lblNameError", ForeColor = System.Drawing.Color.Red };

            // Account Number
            var lblNumber = new Label { Text = "<br />Account Number (14 digits): " };
            var txtNumber = new TextBox { ID = "txtNumber", MaxLength = 14 };
            var lblNumberError = new Label { ID = "lblNumberError", ForeColor = System.Drawing.Color.Red };

            // Pin Number (Set to Password mode and handle postback)
            var lblPin = new Label { Text = "<br />PIN Number (4 digits): " };
            var txtPin = new TextBox { ID = "txtPin", MaxLength = 4 };
            var lblPinError = new Label { ID = "lblPinError", ForeColor = System.Drawing.Color.Red };

            // Account Type
            var lblType = new Label { Text = "<br />Account Type: " };
            var rblType = new RadioButtonList { ID = "rblType", CssClass = "radiobuttonlist" };
            rblType.Items.Add(new ListItem("Current", "Current"));
            rblType.Items.Add(new ListItem("Savings", "Savings"));
            var lblTypeError = new Label { ID = "lblTypeError", ForeColor = System.Drawing.Color.Red };

            // Additional Options for Current Accounts
            var lblCurrentOptions = new Label { Text = "<br />Minimum 5000 Balance in Current Account: ", ID = "lblCurrentOptions", Visible = false };
            var rblCurrentOptions = new RadioButtonList { ID = "rblCurrentOptions", CssClass = "radiobuttonlist", Visible = false };
            rblCurrentOptions.Items.Add(new ListItem("Yes", "Yes"));
            rblCurrentOptions.Items.Add(new ListItem("No", "No"));
            var lblCurrentOptionsError = new Label { ID = "lblCurrentOptionsError", ForeColor = System.Drawing.Color.Red };

            rblType.SelectedIndexChanged += (s, e) =>
            {
                lblCurrentOptions.Visible = (rblType.SelectedValue == "Current");
                rblCurrentOptions.Visible = (rblType.SelectedValue == "Current");
            };
            rblType.AutoPostBack = true;

            // Create Account Button
            var btnSubmit = new Button { Text = "Create Account", ID = "btnSubmit", CssClass = "btn" };
            btnSubmit.Click += (s, e) =>
            {
                bool isValid = true;
                lblNameError.Text = "";
                lblNumberError.Text = "";
                lblPinError.Text = "";
                lblTypeError.Text = "";
                lblCurrentOptionsError.Text = "";

                // Validate Name
                if (!Regex.IsMatch(txtName.Text, @"^[a-zA-Z\s]{1,30}$"))
                {
                    lblNameError.Text = "Name must contain only alphabets and be up to 30 characters.";
                    isValid = false;
                }

                // Validate Account Number
                if (!Regex.IsMatch(txtNumber.Text, @"^\d{14}$"))
                {
                    lblNumberError.Text = "Account Number must be exactly 14 numeric digits.";
                    isValid = false;
                }

                // Validate Pin Number
                if (!Regex.IsMatch(txtPin.Text, @"^\d{4}$"))
                {
                    lblPinError.Text = "Pin Number must be exactly 4 numeric digits.";
                    isValid = false;
                }

                // Validate Account Type Selection
                if (rblType.SelectedIndex == -1)
                {
                    lblTypeError.Text = "Please select an Account Type.";
                    isValid = false;
                }

                // Validate Current Account Options if 'Current' is selected
                if (rblType.SelectedValue == "Current" && rblCurrentOptions.SelectedIndex == -1)
                {
                    lblCurrentOptionsError.Text = "Please select whether the balance will be 5000 or not.";
                    isValid = false;
                }

                // Handle Current Account Options
                double initialBalance = 0;
                if (rblType.SelectedValue == "Current")
                {
                    if (rblCurrentOptions.SelectedValue == "Yes")
                    {
                        initialBalance = 5000; // Default balance for Current Account
                    }
                    else if (rblCurrentOptions.SelectedValue == "No")
                    {
                        BankerMenu.Controls.Add(new Label { Text = "<br />Account creation canceled.<br />", ForeColor = System.Drawing.Color.Red });
                        return;
                    }
                }

                // Proceed if valid
                if (isValid)
                {
                    var newAccount = new BankAccount
                    {
                        AccountHolderName = txtName.Text,
                        AccountNumber = long.Parse(txtNumber.Text),
                        PinNumber = txtPin.Text,  // Storing the Pin Number
                        AccountType = rblType.SelectedValue,
                        AccountBalance = initialBalance // Assign default or zero balance
                    };
                    Accounts.Add(newAccount);

                    BankerMenu.Controls.Add(new Label { Text = "<br />Account created successfully!<br />", ForeColor = System.Drawing.Color.Green });
                }
            };

            // Back Button
            var btnBack = new Button { Text = "Back to Banker Menu", ID = "btnBack", CssClass = "btn" };
            btnBack.Click += (s, e) => DisplayBankerMenu();
            container.Controls.Add(lblTitle);
            container.Controls.Add(lblName);
            container.Controls.Add(txtName);
            container.Controls.Add(lblNameError);
            container.Controls.Add(lblNumber);
            container.Controls.Add(txtNumber);
            container.Controls.Add(lblNumberError);
            container.Controls.Add(lblPin);
            container.Controls.Add(txtPin);
            container.Controls.Add(lblPinError);
            container.Controls.Add(lblType);
            container.Controls.Add(rblType);
            container.Controls.Add(lblTypeError);
            container.Controls.Add(lblCurrentOptions);
            container.Controls.Add(rblCurrentOptions);
            container.Controls.Add(lblCurrentOptionsError);
            container.Controls.Add(btnSubmit);
            container.Controls.Add(btnBack);

            // Add container to the BankerMenu
            BankerMenu.Controls.Add(container);
        }
        private void DisplayAllAccounts()
        {
            ViewState["CurrentView"] = "DisplayAllAccounts"; // Keep banker menu view
            BankerMenu.Controls.Clear(); // Clear the current content

            // Create a container Panel
            var container = new Panel { CssClass = "form-container" };

            // Title Label
            var lblTitle = new Label { Text = "<h3>All Bank Accounts</h3>", EnableViewState = false, CssClass = "title" };
            container.Controls.Add(lblTitle);

            // Check if there are no accounts
            if (Accounts.Count == 0)
            {
                var lblNoAccounts = new Label { Text = "<br />No accounts available.<br />" };
                container.Controls.Add(lblNoAccounts);
            }
            else
            {
                // Display account details
                foreach (var account in Accounts)
                {
                    var lblAccountDetails = new Label
                    {
                        Text = "Account Holder: " + account.AccountHolderName +
                               ", Account Number: " + account.AccountNumber +
                               ", Balance: " + account.AccountBalance.ToString("C") + "<br />"
                    };
                    container.Controls.Add(lblAccountDetails);
                }
            }

            // Back Button
            var btnBack = new Button { Text = "Back to Banker Menu", ID = "btnBack", CssClass = "btn" };
            // This button goes to the banker menu
            btnBack.Click += (s, e) => DisplayBankerMenu();
            container.Controls.Add(btnBack);

            // Add the container to BankerMenu
            BankerMenu.Controls.Add(container);
        }


        private void RemoveAccount()
        {
            ViewState["CurrentView"] = "RemoveAccountForm";
            BankerMenu.Controls.Clear();

            var container = new Panel { CssClass = "container" };

            // Create labels, textboxes, and buttons as before
            var lblAccountNumber = new Label { Text = "Enter Account Number to Remove: " };
            var txtAccountNumber = new TextBox { ID = "txtAccountNumber" };
            var lblAccountNumberError = new Label { ID = "lblAccountNumberError", ForeColor = System.Drawing.Color.Red };

            var btnSubmit = new Button { Text = "Remove Account", ID = "btnSubmit", CssClass = "btn" };
            btnSubmit.Click += (s, e) =>
            {
                lblAccountNumberError.Text = "";

                // Validate Account Number
                if (string.IsNullOrEmpty(txtAccountNumber.Text) || !Regex.IsMatch(txtAccountNumber.Text, @"^\d{14}$"))
                {
                    lblAccountNumberError.Text = "Please enter a valid 14-digit account number.";
                }
                else
                {
                    var account = Accounts.Find(a => a.AccountNumber.ToString() == txtAccountNumber.Text);
                    if (account != null)
                    {
                        Accounts.Remove(account);
                        BankerMenu.Controls.Add(new Label { Text = "Account removed successfully!", ForeColor = System.Drawing.Color.Green });
                    }
                    else
                    {
                        lblAccountNumberError.Text = "Account not found.";
                    }
                }
            };

            // Back Button
            var btnBack = new Button { Text = "Back to Banker Menu", ID = "btnBack", CssClass = "btn" };
            btnBack.Click += (s, e) => DisplayBankerMenu();

            // Add controls to container
            container.Controls.Add(lblAccountNumber);
            container.Controls.Add(txtAccountNumber);
            container.Controls.Add(lblAccountNumberError);
            container.Controls.Add(btnSubmit);
            container.Controls.Add(btnBack);

            // Add container to BankerMenu
            BankerMenu.Controls.Add(container);
        } 



        private void DisplayCustomerLogin()
        {
            ViewState["CurrentView"] = "CustomerMenu";
            MainMenu.Visible = false;
            BankerMenu.Visible = false;
            CustomerMenu.Visible = true;
            CustomerMenu.Controls.Clear();

            // Create a container Panel
            var container = new Panel { CssClass = "form-container" };

            // Title Label
            var lblTitle = new Label { Text = "<h3>Customer Login</h3>", EnableViewState = false, CssClass = "title" };
            container.Controls.Add(lblTitle);

            // Account Number
            var lblAccountNumber = new Label { Text = "Account Number: " };
            var txtAccountNumber = new TextBox { ID = "txtAccountNumber" ,MaxLength = 14 };
            container.Controls.Add(lblAccountNumber);
            container.Controls.Add(txtAccountNumber);

            // PIN
            var lblPin = new Label { Text = "<br />PIN: " };
            var txtPin = new TextBox { ID = "txtPin", TextMode = TextBoxMode.Password, MaxLength = 4};
            container.Controls.Add(lblPin);
            container.Controls.Add(txtPin);

            // Error Label
            var lblError = new Label { ID = "lblError", ForeColor = System.Drawing.Color.Red };
            container.Controls.Add(lblError);

            // Login Button
            var btnLogin = new Button { Text = "Login", ID = "btnLogin", CssClass = "btn" };
            btnLogin.Click += (s, e) =>
            {
                long accountNumber;
                bool isAccountNumberValid = long.TryParse(txtAccountNumber.Text, out accountNumber);
                var pin = txtPin.Text;

                if (isAccountNumberValid)
                {
                    var account = Accounts.Find(acc => acc.AccountNumber == accountNumber && acc.PinNumber == pin);

                    if (account != null)
                    {
                        Session["CurrentAccount"] = account; // Store the account object in session
                        DisplayCustomerDashboard();
                    }
                    else
                    {
                        lblError.Text = "Invalid Account Number or PIN.";
                    }
                }
                else
                {
                    lblError.Text = "Invalid Account Number format.";
                }
            };
            container.Controls.Add(btnLogin);

            // Back Button
            var btnBack = new Button { Text = "Back to Main Menu", ID = "btnBack", CssClass = "btn" };
            btnBack.Click += (s, e) => DisplayMainMenu();
            container.Controls.Add(btnBack);

            // Add the container to CustomerMenu
            CustomerMenu.Controls.Add(container);
        }


        private void DisplayCustomerDashboard()
        {
            ViewState["CurrentView"] = "CustomerDashboard";
            CustomerMenu.Controls.Clear();
            CustomerMenu.Visible = true;
            MainMenu.Visible = false;
            BankerMenu.Visible = false;

            // Create a container Panel
            var container = new Panel { CssClass = "dashboard-container" };

            // Title Label
            var lblTitle = new Label { Text = "<h3>Customer Dashboard</h3>", EnableViewState = false, CssClass = "title" };
            container.Controls.Add(lblTitle);

            // Check Balance Button
            var btnCheckBalance = new Button { Text = "Check Balance", ID = "btnCheckBalance", CssClass = "btn" };
            btnCheckBalance.Click += (s, e) => CheckBalance();
            container.Controls.Add(btnCheckBalance);

            // Withdraw Button
            var btnWithdraw = new Button { Text = "Withdraw", ID = "btnWithdraw", CssClass = "btn" };
            btnWithdraw.Click += (s, e) => WithdrawAmount();
            container.Controls.Add(btnWithdraw);

            // Deposit Button
            var btnDeposit = new Button { Text = "Deposit", ID = "btnDeposit", CssClass = "btn" };
            btnDeposit.Click += (s, e) => DepositAmount();
            container.Controls.Add(btnDeposit);

            // Log Out Button
            var btnBack = new Button { Text = "Log Out", ID = "btnBack", CssClass = "btn" };
            btnBack.Click += (s, e) => DisplayCustomerLogin();
            container.Controls.Add(btnBack);

            // Add the container to CustomerMenu
            CustomerMenu.Controls.Add(container);
        }


        private void CheckBalance()
        {
            var container = new Panel { CssClass = "balance-container" };

            var account = Session["CurrentAccount"] as BankAccount;
            if (account == null)
            {
                container.Controls.Add(new Label { Text = "<br />Please log in to access this feature.", ForeColor = System.Drawing.Color.Red });
            }
            else
            {
                container.Controls.Add(new Label { Text = "<br />Balance: " + account.AccountBalance.ToString("C"), ForeColor = System.Drawing.Color.Green });
            }
            container.Controls.Add(new LiteralControl("<br />"));
            Button btnBack = new Button { Text = "Back", ID = "btnBackBalance", CssClass = "btn" };

            btnBack.Click += (s, e) => DisplayCustomerDashboard();
            container.Controls.Add(btnBack);
            CustomerMenu.Controls.Clear();
            CustomerMenu.Controls.Add(container);
        }
        private void WithdrawAmount()
        {
            ViewState["CurrentView"] = "WithdrawForm";
            CustomerMenu.Controls.Clear();

            var container = new Panel { CssClass = "withdraw-container" };

            Label lblAmount = new Label { Text = "Enter Amount to Withdraw: ", ID = "lblWithdrawAmount" };
            TextBox txtAmount = new TextBox { ID = "txtWithdrawAmount" };
            Button btnWithdraw = new Button { Text = "Withdraw", ID = "btnConfirmWithdraw", CssClass = "btn" };
            Label lblError = new Label { ID = "lblWithdrawError", ForeColor = System.Drawing.Color.Red };
            Button btnBack = new Button { Text = "Back", ID = "btnBackWithdraw", CssClass = "btn" };

            btnBack.Click += (s, e) => DisplayCustomerDashboard();
            btnWithdraw.Click += (s, e) =>
            {
                var account = Session["CurrentAccount"] as BankAccount;
                if (account == null)
                {
                    lblError.Text = "No account found. Please log in again.";
                    return;
                }

                double amount;
                if (!double.TryParse(txtAmount.Text, out amount) || amount <= 0)
                {
                    lblError.Text = "Invalid amount. Please enter a positive number.";
                    return;
                }

                if (account.AccountBalance < amount)
                {
                    lblError.Text = "Insufficient balance.";
                    return;
                }

                account.AccountBalance -= amount;
                lblError.ForeColor = System.Drawing.Color.Green;
                lblError.Text = "Withdrawal successful. New Balance: " + account.AccountBalance.ToString("C");
            };

            container.Controls.Add(lblAmount);
            container.Controls.Add(txtAmount);
            container.Controls.Add(btnWithdraw);
            container.Controls.Add(lblError);
            container.Controls.Add(btnBack);

            CustomerMenu.Controls.Add(container);
        }
        private void DepositAmount()
        {
            ViewState["CurrentView"] = "DepositForm";
            CustomerMenu.Controls.Clear();

            var container = new Panel { CssClass = "deposit-container" };

            Label lblAmount = new Label { Text = "Enter Amount to Deposit: ", ID = "lblDepositAmount" };
            TextBox txtAmount = new TextBox { ID = "txtDepositAmount" };
            Button btnDeposit = new Button { Text = "Deposit", ID = "btnConfirmDeposit", CssClass = "btn" };
            Label lblError = new Label { ID = "lblDepositError", ForeColor = System.Drawing.Color.Red };
            Button btnBack = new Button { Text = "Back", ID = "btnBackDeposit", CssClass = "btn" };

            btnBack.Click += (s, e) => DisplayCustomerDashboard();
            btnDeposit.Click += (s, e) =>
            {
                var account = Session["CurrentAccount"] as BankAccount;
                if (account == null)
                {
                    lblError.Text = "No account found. Please log in again.";
                    return;
                }

                double amount;
                if (!double.TryParse(txtAmount.Text, out amount) || amount <= 0)
                {
                    lblError.Text = "Invalid amount. Please enter a positive number.";
                    return;
                }

                account.AccountBalance += amount;
                lblError.ForeColor = System.Drawing.Color.Green;
                lblError.Text = "Deposit successful. New Balance: " + account.AccountBalance.ToString("C");
            };

            container.Controls.Add(lblAmount);
            container.Controls.Add(txtAmount);
            container.Controls.Add(btnDeposit);
            container.Controls.Add(lblError);
            container.Controls.Add(btnBack);

            CustomerMenu.Controls.Add(container);
        }






        private void ExitApplication()
        {
            // Clear the session data
            Session.Clear();

            // Clear controls and show a goodbye message
            MainMenu.Controls.Clear();
            BankerMenu.Controls.Clear();
            CustomerMenu.Controls.Clear();

            var lblGoodbye = new Label
            {
                Text = "<h3>Thank you for using the Bank Management System. Goodbye!</h3>",
                ForeColor = System.Drawing.Color.Blue,
                EnableViewState = false
            };
            MainMenu.Controls.Add(lblGoodbye);
        }

    }
}
