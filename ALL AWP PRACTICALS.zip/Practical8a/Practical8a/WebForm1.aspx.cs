﻿using System;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical8a
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection cn = new SqlConnection(@"Data Source=localhost\SQLExpress;Initial Catalog=EmployeeDB;Integrated Security=True");
        SqlCommand co = new SqlCommand();

        // Declare controls at the class level
        protected TextBox txtEmpId, txtEmpName, txtEmpCity, txtEmpSalary;
        protected Button btnAdd;
        protected Label lblResult, lblName;
        protected GridView gridView;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Create controls dynamically
            lblName = new Label();
            lblName.Text = "Employee Information";
            form1.Controls.Add(lblName);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create Label and TextBox for Emp_ID
            lblName = new Label();
            lblName.Text = "Emp_ID: ";
            form1.Controls.Add(lblName);

            txtEmpId = new TextBox();
            txtEmpId.ID = "txtEmpId";
            form1.Controls.Add(txtEmpId);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create Label and TextBox for Emp_Name
            lblName = new Label();
            lblName.Text = "Emp_Name: ";
            form1.Controls.Add(lblName);

            txtEmpName = new TextBox();
            txtEmpName.ID = "txtEmpName";
            form1.Controls.Add(txtEmpName);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create Label and TextBox for Emp_City
            lblName = new Label();
            lblName.Text = "Emp_City: ";
            form1.Controls.Add(lblName);

            txtEmpCity = new TextBox();
            txtEmpCity.ID = "txtEmpCity";
            form1.Controls.Add(txtEmpCity);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create Label and TextBox for Emp_Salary
            lblName = new Label();
            lblName.Text = "Emp_Salary: ";
            form1.Controls.Add(lblName);

            txtEmpSalary = new TextBox();
            txtEmpSalary.ID = "txtEmpSalary";
            form1.Controls.Add(txtEmpSalary);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create Add Button
            btnAdd = new Button();
            btnAdd.Text = "Add Employee";
            btnAdd.Click += new EventHandler(btnAdd_Click);
            form1.Controls.Add(btnAdd);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create Label for showing result
            lblResult = new Label();
            lblResult.ID = "lblResult";
            form1.Controls.Add(lblResult);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create GridView to show data
            gridView = new GridView();
            gridView.ID = "gridView";
            form1.Controls.Add(gridView);

            // Bind GridView on first load
            if (!IsPostBack)
            {
                BindGrid();
            }

            // Open the connection
            cn.Open();
            co.Connection = cn;
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            // Use parameterized query to insert data
            co.CommandText = "INSERT INTO Employee (empID, empName, empCity, empSalary) VALUES (@empID, @empName, @empCity, @empSalary)";
            co.Parameters.Clear();
            co.Parameters.AddWithValue("@empID", txtEmpId.Text);
            co.Parameters.AddWithValue("@empName", txtEmpName.Text);
            co.Parameters.AddWithValue("@empCity", txtEmpCity.Text);
            co.Parameters.AddWithValue("@empSalary", txtEmpSalary.Text);

            int rowsAffected = co.ExecuteNonQuery();

            // Show result
            if (rowsAffected > 0)
            {
                lblResult.Text = "Employee added successfully!";
            }
            else
            {
                lblResult.Text = "Failed to add employee.";
            }

            // Clear textboxes
            txtEmpId.Text = "";
            txtEmpName.Text = "";
            txtEmpCity.Text = "";
            txtEmpSalary.Text = "";

            // Refresh the GridView
            BindGrid();
        }

        // Method to bind data to GridView
        private void BindGrid()
        {
            co.CommandText = "SELECT empID, empName, empCity, empSalary FROM Employee";
            SqlDataReader reader = co.ExecuteReader();

            DataTable dt = new DataTable();
            dt.Load(reader);

            gridView.DataSource = dt;
            gridView.DataBind();

            reader.Close();
        }
    }
}
