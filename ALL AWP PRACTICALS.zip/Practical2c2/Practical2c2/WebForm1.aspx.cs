﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

class Calculator
{
    public int Divide(int dividend, int divisor)
    {
        return dividend / divisor;
    }
}

namespace Practical2c2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        // Declare TextBox controls and result Label
        TextBox txtDividend = new TextBox(); // Initialize for dividend input
        TextBox txtDivisor = new TextBox(); // Initialize for divisor input
        Label lblResult = new Label(); // Initialize for result display

        protected void Page_Load(object sender, EventArgs e)
        {
            // Creating and setting properties for the first Label (Dividend)
            Label lblDividendPrompt = new Label();
            lblDividendPrompt.Text = "Enter the dividend: ";
            form1.Controls.Add(lblDividendPrompt);

            txtDividend.ID = "txtDividend"; // Set ID for txtDividend
            form1.Controls.Add(txtDividend); // Add dividend input TextBox

            // Line break
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Creating and setting properties for the second Label (Divisor)
            Label lblDivisorPrompt = new Label();
            lblDivisorPrompt.Text = "Enter the divisor: ";
            form1.Controls.Add(lblDivisorPrompt);

            txtDivisor.ID = "txtDivisor"; // Set ID for txtDivisor
            form1.Controls.Add(txtDivisor); // Add divisor input TextBox

            // Line break
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Creating and setting properties for the Button
            Button cmdDivide = new Button(); // Button renamed
            cmdDivide.ID = "cmdDivide"; // Set ID for cmdDivide
            cmdDivide.Text = "Divide"; // Button text
            cmdDivide.Click += new EventHandler(cmdDivide_Click); // Event handler updated
            form1.Controls.Add(cmdDivide); // Add divide Button

            // Line break
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Creating and setting properties for the result Label
            lblResult.ID = "lblResult"; // Set ID for lblResult
            form1.Controls.Add(lblResult); // Add result Label
        }


        protected void cmdDivide_Click(object sender, EventArgs e)
        {
            try
            {
                // Parse the input values directly from the initialized TextBoxes
                int dividend = int.Parse(txtDividend.Text); // Direct access
                int divisor = int.Parse(txtDivisor.Text); // Direct access

                // Create an instance of the Calculator class
                Calculator calculator = new Calculator();

                // Perform division
                int result = calculator.Divide(dividend, divisor);

                // Display the result in the result Label
                lblResult.Text = "Result: " + result; // Direct access
            }
            catch (DivideByZeroException)
            {
                // Handling divide-by-zero exception
                lblResult.Text = "Error: Cannot divide by zero.";
            }
            catch (FormatException)
            {
                // Handling format exception (e.g., when input is not a valid number)
                lblResult.Text = "Error: Invalid input format.";
            }
            catch
            {
                // Handling any other exceptions
                lblResult.Text = "An unexpected error occurred.";
            }
            finally
            {
                // Code that runs regardless of whether an exception occurred or not
                lblResult.Text += "<br />Operation completed.";
            }
        }

    }
}