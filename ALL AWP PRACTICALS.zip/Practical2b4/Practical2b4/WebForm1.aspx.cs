﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical2b4
{
    interface ICalculator
    {
        int Add(int a, int b);
    }

    class Calculator : ICalculator
    {
        public int Add(int a, int b)
        {
            return a + b;
        }
    }

    public partial class WebForm1 : System.Web.UI.Page
    {
        // Declare TextBox controls and result Label
        TextBox txtNum1 = new TextBox(); // Initialize txtNum1 before Page_Load
        TextBox txtNum2 = new TextBox(); // Initialize txtNum2 before Page_Load
        Label lblResult = new Label(); // Initialize lblResult before Page_Load

        protected void Page_Load(object sender, EventArgs e)
        {
            // Creating and setting properties for the first Label
            Label lblNum1Prompt = new Label();
            lblNum1Prompt.Text = "Enter the 1st number: ";
            form1.Controls.Add(lblNum1Prompt);

            txtNum1.ID = "txtNum1"; // Set ID for txtNum1
            form1.Controls.Add(txtNum1);

            // Line break
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Creating and setting properties for the second Label
            Label lblNum2Prompt = new Label();
            lblNum2Prompt.Text = "Enter the 2nd number: ";
            form1.Controls.Add(lblNum2Prompt);

            txtNum2.ID = "txtNum2"; // Set ID for txtNum2
            form1.Controls.Add(txtNum2);

            // Line break
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Creating and setting properties for the Button
            Button cmdAddNumbers = new Button(); // Button renamed
            cmdAddNumbers.ID = "cmdAddNumbers"; // Set ID for cmdAddNumbers
            cmdAddNumbers.Text = "Add Numbers"; // Button text
            cmdAddNumbers.Click += new EventHandler(cmdAddNumbers_Click); // Event handler updated
            form1.Controls.Add(cmdAddNumbers);

            // Line break
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Creating and setting properties for the result Label
            lblResult.ID = "lblResult"; // Set ID for lblResult
            form1.Controls.Add(lblResult);
        }

        protected void cmdAddNumbers_Click(object sender, EventArgs e)
        {
            // Parse the input values directly from the initialized TextBoxes
            int number1 = int.Parse(txtNum1.Text); // Direct access
            int number2 = int.Parse(txtNum2.Text); // Direct access

            // Create an instance of the Calculator class that implements ICalculator
            ICalculator calculator = new Calculator();
            int result = calculator.Add(number1, number2);

            // Display the result in the result Label
            lblResult.Text = "The sum of " + number1 + " and " + number2 + " is: " + result; // Direct access
        }
    }
}
