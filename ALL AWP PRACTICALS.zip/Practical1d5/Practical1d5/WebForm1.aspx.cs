﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical1d5
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Creating and setting properties for Label
            Label label1 = new Label();
            label1.ID = "Label1";
            label1.Text = "Enter a number: ";
            form1.Controls.Add(label1);

            // Creating and setting properties for TextBox
            TextBox textBox1 = new TextBox();
            textBox1.ID = "TextBox1";
            form1.Controls.Add(textBox1);

            // Line break
            form1.Controls.Add(new LiteralControl("<br />"));

            // Creating and setting properties for Button
            Button button1 = new Button();
            button1.ID = "Button1";
            button1.Text = "Process Number";
            button1.Click += new EventHandler(Button1_Click);
            form1.Controls.Add(button1);

            // Line break
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Creating and setting properties for Result Label
            Label resultLabel = new Label();
            resultLabel.ID = "ResultLabel";
            form1.Controls.Add(resultLabel);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            TextBox textBox1 = (TextBox)form1.FindControl("TextBox1");
            Label resultLabel = (Label)form1.FindControl("ResultLabel");

            int num = System.Convert.ToInt32(textBox1.Text);

            // Create an instance of NumberProcessor
            NumberProcessor processor = new NumberProcessor();

            // Use the NumberProcessor object to reverse the number and calculate the sum of digits
            int reversedNum;
            int sumOfDigits;
            processor.ReverseNumber(num, out reversedNum, out sumOfDigits);

            resultLabel.Text = string.Format("Reversed number: {0}<br/>Sum of Digits: {1}", reversedNum, sumOfDigits);
        }
    }

    public class NumberProcessor
    {
        public void ReverseNumber(int num, out int reversedNum, out int sumOfDigits)
        {
            reversedNum = 0;
            sumOfDigits = 0;

            while (num != 0)
            {
                int digit = num % 10;
                reversedNum = reversedNum * 10 + digit;
                sumOfDigits += digit;
                num /= 10;
            }
        }
    }
}
