﻿using System;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace Practical9a
{
    public partial class p8c : System.Web.UI.Page
    {
        // Connection string for your database (adjust accordingly)
        string connectionString = "Data Source=localhost\\SQLExpress;Initial Catalog=EmployeeDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Get empID from query string
                string empID = Request.QueryString["empID"];
                if (!string.IsNullOrEmpty(empID))
                {
                    LoadEmployeeDetails(empID);
                }
                else
                {
                    lblEmpID.Text = "Employee ID not provided.";
                }
            }
        }

        private void LoadEmployeeDetails(string empID)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT empName, empCity, empSalary FROM Employee WHERE empID = @empID";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@empID", empID);

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            lblEmpID.Text = "Employee ID: " + empID;
                            lblEmpName.Text = "Name: " + reader["empName"].ToString();
                            lblEmpCity.Text = "City: " + reader["empCity"].ToString();
                            lblEmpSalary.Text = "Salary: " + reader["empSalary"].ToString();
                        }
                        else
                        {
                            lblEmpID.Text = "Employee not found.";
                        }
                    }
                }
            }
        }
    }
}
