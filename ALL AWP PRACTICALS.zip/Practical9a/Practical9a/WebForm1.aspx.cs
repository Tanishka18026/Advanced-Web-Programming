﻿using System;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace Practical9a
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        GridView gridView;
        SqlDataSource sqlDataSource;

        // Connection string for your database (hardcoded for example)
        string connectionString = "Data Source=localhost\\SQLExpress;Initial Catalog=EmployeeDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            // Create SqlDataSource dynamically
            sqlDataSource = new SqlDataSource();
            sqlDataSource.ID = "SqlDataSource1";
            sqlDataSource.ConnectionString = connectionString;
            sqlDataSource.SelectCommand = "SELECT * FROM Employee"; // Adjust to your table and fields
            this.Page.Controls.Add(sqlDataSource);  // Add SqlDataSource to the page controls

            // Create GridView dynamically
            gridView = new GridView();
            gridView.ID = "GridView1";
            gridView.AutoGenerateColumns = false; // False so we can define custom columns
            gridView.DataSourceID = sqlDataSource.ID;

            // Add columns dynamically

            // HyperLinkField for Employee ID with link to another page (p8c.aspx)
            HyperLinkField linkField = new HyperLinkField();
            linkField.DataNavigateUrlFields = new string[] { "empID" };
            linkField.DataNavigateUrlFormatString = "~/p8c.aspx?empID={0}";
            linkField.DataTextField = "empID";
            linkField.HeaderText = "Emp ID";
            gridView.Columns.Add(linkField);

            // BoundField for Employee Name
            BoundField empNameField = new BoundField();
            empNameField.DataField = "empName";
            empNameField.HeaderText = "Emp Name";
            gridView.Columns.Add(empNameField);

            // BoundField for Employee Salary
            BoundField empSalField = new BoundField();
            empSalField.DataField = "empSalary";
            empSalField.HeaderText = "Emp Salary";
            gridView.Columns.Add(empSalField);

            // Add GridView to the form controls
            this.form1.Controls.Add(gridView);

            // Bind data to the GridView
            gridView.DataBind();
        }
    }
}
