﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical9b
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected GridView GridView1;
        protected Label Label1;

        // Your connection string
        string connectionString = "Data Source=localhost\\SQLExpress;Initial Catalog=EmployeeDB;Integrated Security=True;";

        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialize GridView and Label
            GridView1 = new GridView();
            GridView1.AutoGenerateColumns = false;
            GridView1.AllowPaging = true; // Enable paging
            GridView1.PageSize = 5; // Set the number of rows per page
            GridView1.RowCommand += GridView1_RowCommand;
            GridView1.PageIndexChanging += GridView1_PageIndexChanging; // Handle page index change

            // Define BoundFields for GridView columns
            GridView1.Columns.Add(CreateBoundField("empID", "Employee ID"));
            GridView1.Columns.Add(CreateBoundField("empName", "Employee Name"));
            GridView1.Columns.Add(CreateBoundField("empCity", "Employee City"));
            GridView1.Columns.Add(CreateBoundField("empSalary", "Employee Salary"));

            // Define TemplateField for the Button
            TemplateField buttonField = new TemplateField();
            buttonField.ItemTemplate = new GridViewButtonTemplate();
            GridView1.Columns.Add(buttonField);

            // Initialize and add Label control
            Label1 = new Label();
            Label1.Text = "Label";

            // Bind data and add controls to page
            if (!IsPostBack) // Bind data only on initial load
            {
                BindGridData();
            }

            form1.Controls.Add(GridView1);
            form1.Controls.Add(Label1);
        }

        private void BindGridData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM Employee"; // Query to fetch employee data
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt); // Fill DataTable with the result set
                GridView1.DataSource = dt;
                GridView1.DataBind(); // Bind the DataTable to the GridView
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Show")
            {
                // Declare index variable to hold the row index
                int index;
                // Check if the CommandArgument is valid
                if (int.TryParse(e.CommandArgument.ToString(), out index))
                {
                    GridViewRow row = GridView1.Rows[index];
                    string name = row.Cells[1].Text; // empName is in Cells[1]
                    Label1.Text = "Name: " + name;
                }
                else
                {
                    Label1.Text = "Error: Invalid row index.";
                }
            }
        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex; // Update the current page index
            BindGridData(); // Rebind data to show the new page
        }

        // Create BoundField dynamically
        private BoundField CreateBoundField(string dataField, string headerText)
        {
            return new BoundField
            {
                DataField = dataField,
                HeaderText = headerText,
                SortExpression = dataField
            };
        }

        // Template class for dynamic button field
        public class GridViewButtonTemplate : ITemplate
        {
            public void InstantiateIn(Control container)
            {
                Button showButton = new Button();
                showButton.Text = "Show";
                showButton.CommandName = "Show";
                showButton.DataBinding += (sender, e) =>
                {
                    Button btn = (Button)sender;
                    GridViewRow row = (GridViewRow)btn.NamingContainer;
                    btn.CommandArgument = row.RowIndex.ToString(); // Correctly bind the row index
                };
                container.Controls.Add(showButton);
            }
        }
    }
}
