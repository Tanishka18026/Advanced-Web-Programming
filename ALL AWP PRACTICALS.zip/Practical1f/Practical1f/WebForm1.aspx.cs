﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical1f
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Create a label for user input
            Label inputLabel = new Label();
            inputLabel.ID = "lblNumberOfRows";
            inputLabel.Text = "Enter the number of rows for Floyd's Triangle: ";
            form1.Controls.Add(inputLabel);

            // Create a textbox for user input
            TextBox inputTextBox = new TextBox();
            inputTextBox.ID = "txtNumberOfRows";
            form1.Controls.Add(inputTextBox);

            // Create a button dynamically
            Button generateButton = new Button();
            generateButton.ID = "btnGenerate";
            generateButton.Text = "Generate Floyd's Triangle";
            generateButton.Click += GenerateButton_Click;
            form1.Controls.Add(generateButton);

            // Create a label control dynamically to display the triangle
            Label triangleOutput = new Label();
            triangleOutput.ID = "lblTriangleOutput";
            form1.Controls.Add(triangleOutput);
        }

        protected void GenerateButton_Click(object sender, EventArgs e)
        {
            // Retrieve the number of rows from the textbox
            TextBox inputTextBox = (TextBox)form1.FindControl("txtNumberOfRows");
            int numberOfRows = Convert.ToInt32(inputTextBox.Text);

            // Generate Floyd's Triangle
            string triangleHtml = GenerateFloydsTriangleHtml(numberOfRows);

            // Find the label control and set its text to the generated triangle
            Label triangleOutput = (Label)form1.FindControl("lblTriangleOutput");
            triangleOutput.Text = "<br/>Here is Floyd's Triangle:<br/>" + triangleHtml;
        }

        private string GenerateFloydsTriangleHtml(int rows)
        {
            string result = "";
            int number = 1;

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j <= i; j++)
                {
                    result += number + " ";
                    number++;
                }
                result += "<br />";
            }

            return result;
        }
    }
}
