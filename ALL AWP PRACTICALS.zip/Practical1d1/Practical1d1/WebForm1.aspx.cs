﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical1d1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        // Declare controls as class-level fields
        private Label label1;
        private TextBox textBox1;
        private Button button1;
        private Label resultLabel;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialize and add Label control
            label1 = new Label();
            label1.ID = "Label1";
            label1.Text = "Number of terms: ";
            form1.Controls.Add(label1);

            // Initialize and add TextBox control
            textBox1 = new TextBox();
            textBox1.ID = "TextBox1";
            form1.Controls.Add(textBox1);

            // Line break
            form1.Controls.Add(new LiteralControl("<br />"));

            // Initialize and add Button control
            button1 = new Button();
            button1.ID = "Button1";
            button1.Text = "Generate Fibonacci Series";
            button1.Click += new EventHandler(Button1_Click);
            form1.Controls.Add(button1);

            // Line break
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Initialize and add Label for results
            resultLabel = new Label();
            resultLabel.ID = "ResultLabel";
            form1.Controls.Add(resultLabel);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Directly parse the input, assuming it's always correct
            int num = int.Parse(textBox1.Text);
            Function obj1 = new Function();
            string fibonacciSeries = obj1.Demo(num);
            resultLabel.Text = fibonacciSeries;
        }
    }

    public class Function
    {
        public string Demo(int num)
        {
            if (num <= 0)
            {
                return "Number must be positive.";
            }
            if (num == 1)
            {
                return "The Fibonacci Series of 1 term is: 0";
            }

            int a = 0, b = 1, c;
            string result = "The Fibonacci Series of " + num + " terms is: " + a + ", " + b;

            for (int i = 2; i < num; i++)
            {
                c = a + b;
                result += ", " + c;
                a = b;
                b = c;
            }

            return result;
        }
    }
}
