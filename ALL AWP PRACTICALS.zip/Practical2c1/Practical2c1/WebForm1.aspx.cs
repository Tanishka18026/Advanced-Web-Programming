﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical2c1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        public delegate void SimpleDelegate();
        public event SimpleDelegate MyEvent;
        protected void Page_Load(object sender, EventArgs e)
        {
            Ex obj = new Ex();
            MyEvent += new SimpleDelegate(obj.CallingFunction);
            MyEvent += new SimpleDelegate(obj.SecFunction);

           
            if (MyEvent != null)
            {
                MyEvent.Invoke();
            }   
            var label = new Label();
            label.Text = "Event and Delegate Demonstration:";
            form1.Controls.Add(label);

            var button = new Button();
            button.Text = "Click Me";
            button.Click += Button_Click;
            form1.Controls.Add(button);
        }
        protected void Button_Click(object sender, EventArgs e)
        {
            Response.Write("Button was clicked!");
        }
    }

    public class Ex
    {
        public delegate void SimpleDelegate();
        public event SimpleDelegate MyEvent;
        public void CallingFunction()
        {
            HttpContext.Current.Response.Write("First Function Called.....<br />");
        }

        // Second function to be called
        public void SecFunction()
         {
            // Writing output to the response is not ideal for web forms;
            // consider using other methods like updating a label or a literal.
            HttpContext.Current.Response.Write("Second Function Called.....<br />");
        }
    }
}
