﻿using System;
using System.Web.UI;
using System.Xml;
using System.Web.UI.WebControls;

namespace Practical10a
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        // Define controls
        TextBox txtName;
        TextBox txtAge;
        Button cmdAddPerson;
        Label lblResult;
        PlaceHolder phControls; // Declare the PlaceHolder control

        protected void Page_Load(object sender, EventArgs e)
        {
            // Check if phControls is null
            if (phControls == null)
            {
                lblResult.Text = "phControls is not initialized.";
                return; // Stop further execution if it's null
            }

            // Initialize controls
            txtName = new TextBox { ID = "txtName" };
            txtAge = new TextBox { ID = "txtAge" };
            cmdAddPerson = new Button { ID = "cmdAddPerson", Text = "Add Person" };
            lblResult = new Label { ID = "lblResult" };

            // Add placeholder attributes manually
            txtName.Attributes["placeholder"] = "Enter Name";
            txtAge.Attributes["placeholder"] = "Enter Age";

            // Attach event handler
            cmdAddPerson.Click += new EventHandler(this.AddPerson_Click);

            // Add controls to the placeholder in the form
            phControls.Controls.Add(new LiteralControl("<br />"));
            phControls.Controls.Add(new LiteralControl("Name: "));
            phControls.Controls.Add(txtName);
            phControls.Controls.Add(new LiteralControl("<br />"));
            phControls.Controls.Add(new LiteralControl("Age: "));
            phControls.Controls.Add(txtAge);
            phControls.Controls.Add(new LiteralControl("<br />"));
            phControls.Controls.Add(cmdAddPerson);
            phControls.Controls.Add(new LiteralControl("<br />"));
            phControls.Controls.Add(lblResult);
            phControls.Controls.Add(new LiteralControl("<br /><br />"));

            // Display the current XML data
            DisplayXmlData();
        }


        protected void AddPerson_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string age = txtAge.Text;

            // Load the XML file
            string filePath = Server.MapPath("~/App_Data/people.xml");
            XmlDocument doc = new XmlDocument();
            doc.Load(filePath);

            // Create new person element
            XmlElement newPerson = doc.CreateElement("Person");
            XmlElement newName = doc.CreateElement("Name");
            XmlElement newAge = doc.CreateElement("Age");

            newName.InnerText = name;
            newAge.InnerText = age;

            newPerson.AppendChild(newName);
            newPerson.AppendChild(newAge);
            doc.DocumentElement.AppendChild(newPerson);

            // Save the updated XML file
            doc.Save(filePath);

            // Show success message
            lblResult.Text = "Person added successfully!";

            // Refresh the XML data display
            DisplayXmlData();
        }

        private void DisplayXmlData()
        {
            string filePath = Server.MapPath("~/App_Data/people.xml");
            XmlDocument doc = new XmlDocument();
            doc.Load(filePath);

            lblResult.Text = "<b>People in the XML file:</b><br />";
            foreach (XmlNode node in doc.DocumentElement.ChildNodes)
            {
                string name = node["Name"].InnerText;
                string age = node["Age"].InnerText;
                lblResult.Text += string.Format("Name: {0}, Age: {1}<br />", name, age);
            }
        }
    }
}
