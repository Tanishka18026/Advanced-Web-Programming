﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical8c
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        Label lbl;
        TextBox txtBox;
        Button btn;
        GridView gridView;

        // Connection string directly in the code
        string connectionString = "Data Source=localhost\\SQLExpress;Initial Catalog=EmployeeDB;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            // Create dynamic controls
            lbl = new Label();
            lbl.Text = "Employee Salary > ";
            this.form1.Controls.Add(lbl);

            txtBox = new TextBox();
            txtBox.ID = "TextBox1";
            this.form1.Controls.Add(txtBox);

            // Add line break
            this.form1.Controls.Add(new Literal { Text = "<br /><br />" });

            btn = new Button();
            btn.Text = "Show";
            btn.Click += Button1_Click;
            this.form1.Controls.Add(btn);

            // Add line break
            this.form1.Controls.Add(new Literal { Text = "<br /><br />" });

            gridView = new GridView();
            gridView.ID = "GridView1";
            gridView.AutoGenerateColumns = true; // Set AutoGenerateColumns to true
            this.form1.Controls.Add(gridView);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Connect to the database using the connection string
            using (SqlConnection scon = new SqlConnection(connectionString))
            {
                scon.Open();

                // Parameterized query to avoid SQL injection
                string query = "SELECT * FROM Employee WHERE empSalary > @salary";
                using (SqlCommand cmd = new SqlCommand(query, scon))
                {
                    cmd.Parameters.AddWithValue("@salary", txtBox.Text); // Using the salary entered in the TextBox

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    // Bind the GridView to the result
                    gridView.DataSource = ds.Tables[0];
                    gridView.DataBind();
                }
            }
        }
    }
}
