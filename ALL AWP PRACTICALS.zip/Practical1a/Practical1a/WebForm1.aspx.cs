﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical1a
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        TextBox textBox1;
        TextBox textBox2;
        TextBox textBox3;
        TextBox textBox4;
        Label resultLabel;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Creating and setting properties for Label 1
            Label label1 = new Label();
            label1.ID = "Label1";
            label1.Text = "Value 1: ";
            form1.Controls.Add(label1);

            // Creating and setting properties for TextBox 1
            textBox1 = new TextBox();
            textBox1.ID = "TextBox1";
            form1.Controls.Add(textBox1);

            form1.Controls.Add(new LiteralControl("<br />"));

            // Creating and setting properties for Label 2
            Label label2 = new Label();
            label2.ID = "Label2";
            label2.Text = "Value 2: ";
            form1.Controls.Add(label2);

            // Creating and setting properties for TextBox 2
            textBox2 = new TextBox();
            textBox2.ID = "TextBox2";
            form1.Controls.Add(textBox2);

            form1.Controls.Add(new LiteralControl("<br />"));

            // Creating and setting properties for Label 3
            Label label3 = new Label();
            label3.ID = "Label3";
            label3.Text = "Value 3: ";
            form1.Controls.Add(label3);

            // Creating and setting properties for TextBox 3
            textBox3 = new TextBox();
            textBox3.ID = "TextBox3";
            form1.Controls.Add(textBox3);

            form1.Controls.Add(new LiteralControl("<br />"));

            // Creating and setting properties for Label 4
            Label label4 = new Label();
            label4.ID = "Label4";
            label4.Text = "Value 4: ";
            form1.Controls.Add(label4);

            // Creating and setting properties for TextBox 4
            textBox4 = new TextBox();
            textBox4.ID = "TextBox4";
            form1.Controls.Add(textBox4);

            form1.Controls.Add(new LiteralControl("<br />"));

            // Creating and setting properties for the Button
            Button button = new Button();
            button.ID = "Button1";
            button.Text = "Calculate Product";
            button.Click += new EventHandler(Button1_Click);
            form1.Controls.Add(button);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Creating and setting properties for the Result Label
            resultLabel = new Label();
            resultLabel.ID = "ResultLabel";
            form1.Controls.Add(resultLabel);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Read values directly from class-level text boxes
            int value1 = int.Parse(textBox1.Text);
            int value2 = int.Parse(textBox2.Text);
            int value3 = int.Parse(textBox3.Text);
            int value4 = int.Parse(textBox4.Text);

            // Calculate the product using Calculator class
            Calculator calculator = new Calculator();
            int product = calculator.CalculateProduct(value1, value2, value3, value4);

            // Display the result
            resultLabel.Text = "The product of " + value1 + ", " + value2 + ", " + value3 + ", and " + value4 + " is: " + product;

        }
        public class Calculator
        {
            public int CalculateProduct(int value1, int value2, int value3, int value4)
            {
                return value1 * value2 * value3 * value4;
            }
        }
    }
}

