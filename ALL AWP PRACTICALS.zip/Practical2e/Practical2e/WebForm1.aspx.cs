﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical2e
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        // Define delegate
        private delegate int Operation(int x, int y);

        // Declare controls at the class level
        Label labelNumber1 = new Label();
        TextBox textBoxNumber1 = new TextBox();
        Label labelNumber2 = new Label();
        TextBox textBoxNumber2 = new TextBox();
        Button buttonAdd = new Button();
        Label labelResultAdd = new Label();
        Button buttonSubtract = new Button();
        Label labelResultSubtract = new Label();

        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialize and add controls to the form

            // Label for the first number
            labelNumber1.Text = "Enter first number: ";
            form1.Controls.Add(labelNumber1);

            // TextBox for the first number
            textBoxNumber1.ID = "TextBoxNumber1";
            form1.Controls.Add(textBoxNumber1);

            // Label for the second number
            labelNumber2.Text = "Enter second number: ";
            form1.Controls.Add(labelNumber2);

            // TextBox for the second number
            textBoxNumber2.ID = "TextBoxNumber2";
            form1.Controls.Add(textBoxNumber2);

            // Button for addition
            buttonAdd.Text = "Add";
            buttonAdd.Click += ButtonAdd_Click;
            form1.Controls.Add(buttonAdd);

            // Label to display addition result
            form1.Controls.Add(labelResultAdd);

            // Button for subtraction
            buttonSubtract.Text = "Subtract";
            buttonSubtract.Click += ButtonSubtract_Click;
            form1.Controls.Add(buttonSubtract);

            // Label to display subtraction result
            form1.Controls.Add(labelResultSubtract);
        }

        // Addition method
        private int Add(int x, int y)
        {
            return x + y;
        }

        // Subtraction method
        private int Subtract(int x, int y)
        {
            return x - y;
        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            // Retrieve and process values directly from the controls
            int number1 = Convert.ToInt32(textBoxNumber1.Text);
            int number2 = Convert.ToInt32(textBoxNumber2.Text);

            Operation addOperation = new Operation(Add);
            int result = addOperation(number1, number2);

            labelResultAdd.Text = "Result of addition: " + result;
        }

        protected void ButtonSubtract_Click(object sender, EventArgs e)
        {
            // Retrieve and process values directly from the controls
            int number1 = Convert.ToInt32(textBoxNumber1.Text);
            int number2 = Convert.ToInt32(textBoxNumber2.Text);

            Operation subtractOperation = new Operation(Subtract);
            int result = subtractOperation(number1, number2);

            labelResultSubtract.Text = "Result of subtraction: " + result;
        }
    }
}
