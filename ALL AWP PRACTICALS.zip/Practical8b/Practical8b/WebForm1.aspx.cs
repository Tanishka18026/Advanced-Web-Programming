﻿using System;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical8b
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        DetailsView dv;
        FormView fv;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialize DetailsView and FormView controls dynamically
            dv = new DetailsView();
            dv.ID = "dvEmployee"; // Set ID for later access if needed
            dv.DataKeyNames = new string[] { "empID" }; // Set the DataKeyNames to bind properly with the Employee table

            fv = new FormView();
            fv.ID = "fvEmployee"; // Set ID for FormView
            fv.DataKeyNames = new string[] { "empID" }; // Set the DataKeyNames

            // Bind data on the first page load (Not on PostBack)
            if (!IsPostBack)
            {
                BindData();
            }

            // Add the controls to the form dynamically
            form1.Controls.Add(dv);
            form1.Controls.Add(new Literal { Text = "<br/><br/>" }); // Line break
            form1.Controls.Add(fv);
        }

        private void BindData()
        {
            // Connection string to your database
            string connectionString = "Data Source=localhost\\SQLExpress;Initial Catalog=EmployeeDB;Integrated Security=True";
            string query = "SELECT * FROM Employee";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();

                SqlDataReader reader = cmd.ExecuteReader();

                // Bind data to DetailsView
                dv.DataSource = reader;
                dv.DataBind();

                // Check if there's more data for FormView
                if (reader.NextResult())
                {
                    fv.DataSource = reader;
                    fv.DataBind();
                }

                // Close the reader
                reader.Close();
            }
        }
    }
}
