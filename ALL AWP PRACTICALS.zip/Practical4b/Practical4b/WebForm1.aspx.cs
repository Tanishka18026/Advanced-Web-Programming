﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical4b
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            AdRotator ad = new AdRotator();
            ad.AdvertisementFile = "~/XMLFile1.xml";
            ad.Target = "_blank";
            ad.Width = 300;
            ad.Height = 250;

            this.form1.Controls.Add(ad);

        }
    }
}