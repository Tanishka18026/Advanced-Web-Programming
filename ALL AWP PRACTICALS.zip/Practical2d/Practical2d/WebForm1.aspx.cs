﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical2d
{
    public partial class WebForm1 : Page
    {
        // Declare controls at the class level
        Label lblInput;
        TextBox txtInput;
        Button btnSubmit;
        Label lblResult;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialize controls before Page_Load
            lblInput = new Label();
            lblInput.Text = "Enter an integer: ";
            form1.Controls.Add(lblInput);

            txtInput = new TextBox();
            txtInput.ID = "txtInput";
            form1.Controls.Add(txtInput);

            btnSubmit = new Button();
            btnSubmit.Text = "Submit";
            btnSubmit.Click += BtnSubmit_Click;
            form1.Controls.Add(btnSubmit);

            lblResult = new Label();
            lblResult.ID = "<br/>lblResult";
            form1.Controls.Add(lblResult);
        }

        private void BtnSubmit_Click(object sender, EventArgs e)
        {
            // No need to use FindControl, use the initialized control directly
            int num = Convert.ToInt32(txtInput.Text);

            // Use BoxUnboxOperations class to box and unbox the value
            object boxedValue = BoxUnboxOperations.Box(num);
            int unboxedValue = BoxUnboxOperations.Unbox(boxedValue);

            // Display results using the initialized Label
            lblResult.Text = "Original value (int): " + num + "<br/>" +
                             "Boxed value (object): " + boxedValue + "<br/>" +
                             "Unboxed value (int): " + unboxedValue;
        }
    }

    // Class that contains the boxing and unboxing logic
    public static class BoxUnboxOperations
    {
        public static object Box(int value)
        {
            return value; // Boxing the integer value into an object
        }

        public static int Unbox(object obj)
        {
            return (int)obj; // Unboxing the object back to an integer
        }
    }
}
