﻿using System;
using System.Web.UI.WebControls;

namespace Practical1d4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Create the button dynamically
            Button dynamicButton = new Button();
            dynamicButton.ID = "Button1";
            dynamicButton.Text = "Click Me";
            dynamicButton.Click += Button1_Click;

            // Add the button to the form controls
            form1.Controls.Add(dynamicButton);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int[] a = { 1, 2, 3, 4 };
            foreach (int i in a)
            {
                Response.Write(i + "<br />"); // Output each integer on a new line
            }

        }
    }
}
