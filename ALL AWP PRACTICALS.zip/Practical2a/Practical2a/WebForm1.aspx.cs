﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical2a
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        TextBox textBox1;
        Label resultLabel;

        protected void Page_Load(object sender, EventArgs e)
        {
         
                // Creating and setting properties for Label
                Label label1 = new Label();
                label1.ID = "Label1";
                label1.Text = "Enter a number to find its factorial: ";
                this.form1.Controls.Add(label1);

                // Creating and setting properties for TextBox
                textBox1 = new TextBox();
                textBox1.ID = "TextBox1";
                this.form1.Controls.Add(textBox1);

                // Line break
                this. form1.Controls.Add(new LiteralControl("<br />"));

                // Creating and setting properties for Button
                Button button1 = new Button();
                button1.ID = "Button1";
                button1.Text = "Calculate Factorial";
                button1.Click += new EventHandler(Button1_Click);
                form1.Controls.Add(button1);

                // Line break
                this.form1.Controls.Add(new LiteralControl("<br /><br />"));

                // Creating and setting properties for Result Label
                resultLabel = new Label();
                resultLabel.ID = "ResultLabel";
                this.form1.Controls.Add(resultLabel);
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            // Parse the input from the class-level TextBox
            int n = int.Parse(textBox1.Text);

            // Create an instance of FactorialCalculator
            FactorialCalculator calculator = new FactorialCalculator();

            // Use the FactorialCalculator object to calculate the factorial
            int result = calculator.CalculateFactorial(n);

            // Display the result
            resultLabel.Text = "Factorial of " + n + "is: " + result;
            //resultLabel.Text = string.Format("Factorial of {0} is {1}", n, result);
        }
    }

    public class FactorialCalculator
    {
        public int CalculateFactorial(int n)
        {
            if (n == 0)
                return 1;
            return n * CalculateFactorial(n - 1);
        }
    }
}
