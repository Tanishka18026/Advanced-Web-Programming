﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical1b
{
    public partial class WebForm1 : Page
    {
        TextBox txtInput; // TextBox renamed
        Button cmdPerformOperations; // Button renamed
        Label lblSorting, lblReversing, lblLastIndexOf, lblLength, lblCopy; // Labels renamed

        protected void Page_Load(object sender, EventArgs e)
        {
            // Create and add a TextBox for user input
            txtInput = new TextBox(); // TextBox renamed
            txtInput.ID = "TextBoxInput";
            txtInput.Text = "HelloWorld";  // Default text for demonstration
            txtInput.Width = 200;
            form1.Controls.Add(txtInput);
            form1.Controls.Add(new LiteralControl("<br />"));

            // Create and add a button to perform string operations
            cmdPerformOperations = new Button(); // Button renamed
            cmdPerformOperations.ID = "ButtonPerformOperations";
            cmdPerformOperations.Text = "Perform String Operations";
            cmdPerformOperations.Click += new EventHandler(ButtonPerformOperations_Click);
            form1.Controls.Add(cmdPerformOperations);
            form1.Controls.Add(new LiteralControl("<br />"));

            // Create and add labels for displaying results
            lblSorting = new Label(); // Label renamed
            lblSorting.ID = "LabelSorting";
            lblSorting.Text = "Sorting: ";
            form1.Controls.Add(lblSorting);
            form1.Controls.Add(new LiteralControl("<br />"));

            lblReversing = new Label(); // Label renamed
            lblReversing.ID = "LabelReversing";
            lblReversing.Text = "Reversing: ";
            form1.Controls.Add(lblReversing);
            form1.Controls.Add(new LiteralControl("<br />"));

            lblLastIndexOf = new Label(); // Label renamed
            lblLastIndexOf.ID = "LabelLastIndexOf";
            lblLastIndexOf.Text = "Last Index Of: ";
            form1.Controls.Add(lblLastIndexOf);
            form1.Controls.Add(new LiteralControl("<br />"));

            lblLength = new Label(); // Label renamed
            lblLength.ID = "LabelLength";
            lblLength.Text = "Length: ";
            form1.Controls.Add(lblLength);
            form1.Controls.Add(new LiteralControl("<br />"));

            lblCopy = new Label(); // Label renamed
            lblCopy.ID = "LabelCopy";
            lblCopy.Text = "Copy: ";
            form1.Controls.Add(lblCopy);
        }

        protected void ButtonPerformOperations_Click(object sender, EventArgs e)
        {
            // Get the user input from the TextBox
            string str = txtInput.Text; // TextBox renamed

            // Perform string operations using the external StringOperations class
            StringOperations operations = new StringOperations();

            lblSorting.Text = "Sorting: " + operations.SortString(str); // Label renamed
            lblReversing.Text = "Reversing: " + operations.ReverseString(str); // Label renamed
            lblLastIndexOf.Text = "Last Index Of 'o': " + operations.LastIndexOf(str, 'o'); // Label renamed
            lblLength.Text = "Length: " + operations.GetLength(str); // Label renamed
            lblCopy.Text = "Copy: " + operations.CopyString(str); // Label renamed
        }
    }

    // Logic class for performing string operations
    public class StringOperations
    {
        public string SortString(string input)
        {
            char[] sortedArray = input.ToCharArray();
            Array.Sort(sortedArray);
            return new string(sortedArray);
        }

        public string ReverseString(string input)
        {
            char[] reversedArray = input.ToCharArray();
            Array.Reverse(reversedArray);
            return new string(reversedArray);
        }

        public int LastIndexOf(string input, char c)
        {
            return input.LastIndexOf(c);
        }

        public int GetLength(string input)
        {
            return input.Length;
        }

        public string CopyString(string input)
        {
            return string.Copy(input);
        }
    }
}
