﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical1d2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Creating and setting properties for Label
            Label label1 = new Label();
            label1.ID = "Label1";
            label1.Text = "Enter a number: ";
            form1.Controls.Add(label1);

            // Creating and setting properties for TextBox
            TextBox textBox1 = new TextBox();
            textBox1.ID = "TextBox1";
            form1.Controls.Add(textBox1);

            // Line break
            form1.Controls.Add(new LiteralControl("<br />"));

            // Creating and setting properties for Button
            Button button1 = new Button();
            button1.ID = "Button1";
            button1.Text = "Check Prime";
            button1.Click += new EventHandler(Button1_Click);
            form1.Controls.Add(button1);

            // Line break
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Creating and setting properties for Result Label
            Label resultLabel = new Label();
            resultLabel.ID = "ResultLabel";
            form1.Controls.Add(resultLabel);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int n;
            TextBox textBox1 = (TextBox)form1.FindControl("TextBox1");
            Label resultLabel = (Label)form1.FindControl("ResultLabel");

            if (int.TryParse(textBox1.Text, out n))
            {
                Demo obj1 = new Demo();
                string result = obj1.funtion(n);
                resultLabel.Text = result;
            }
            else
            {
                resultLabel.Text = "Please enter a valid number.";
            }
        }
    }

    public class Demo
    {
        public string funtion(int n)
        {
            int a = 0;
            for (int i = 1; i <= n; i++)
            {
                if (n % i == 0)
                {
                    a++;
                }
            }
            if (a == 2)
            {
                return string.Format("{0} is a Prime Number", n);
            }
            else
            {
                return string.Format("{0} is not a Prime Number", n);
            }
        }
    }
}
