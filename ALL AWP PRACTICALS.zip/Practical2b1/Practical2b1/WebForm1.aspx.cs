﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical2b1
{
    public partial class WebForm1 : Page
    {
        // Declare controls at the class level
        Label lblSideLength, lblSquareResult, lblLength, lblWidth, lblRectangleResult;
        TextBox txtSideLength, txtLength, txtWidth;
        Button cmdCalculateSquare, cmdCalculateRectangle;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Initialize controls regardless of postback
            // This ensures controls persist across postbacks

            // Square area calculation controls
            lblSideLength = new Label();
            lblSideLength.Text = "Enter the side length of the square:";
            form1.Controls.Add(lblSideLength);

            txtSideLength = new TextBox();
            txtSideLength.ID = "txtSideLength"; // Ensure unique ID for state management
            form1.Controls.Add(txtSideLength);
            form1.Controls.Add(new LiteralControl("<br />"));

            cmdCalculateSquare = new Button();
            cmdCalculateSquare.Text = "Calculate Square Area";
            cmdCalculateSquare.Click += new EventHandler(ButtonCalculateSquare_Click);
            form1.Controls.Add(cmdCalculateSquare);
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            lblSquareResult = new Label();
            form1.Controls.Add(lblSquareResult);
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Rectangle area calculation controls
            lblLength = new Label();
            lblLength.Text = "Enter the length of the rectangle:";
            form1.Controls.Add(lblLength);

            txtLength = new TextBox();
            txtLength.ID = "txtLength";
            form1.Controls.Add(txtLength);
            form1.Controls.Add(new LiteralControl("<br />"));

            lblWidth = new Label();
            lblWidth.Text = "Enter the width of the rectangle:";
            form1.Controls.Add(lblWidth);

            txtWidth = new TextBox();
            txtWidth.ID = "txtWidth";
            form1.Controls.Add(txtWidth);
            form1.Controls.Add(new LiteralControl("<br />"));

            cmdCalculateRectangle = new Button();
            cmdCalculateRectangle.Text = "Calculate Rectangle Area";
            cmdCalculateRectangle.Click += new EventHandler(ButtonCalculateRectangle_Click);
            form1.Controls.Add(cmdCalculateRectangle);
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            lblRectangleResult = new Label();
            form1.Controls.Add(lblRectangleResult);
        }

        protected void ButtonCalculateSquare_Click(object sender, EventArgs e)
        {
            // Directly use class-level controls
            double sideLength = Convert.ToDouble(txtSideLength.Text);

            // Create an instance of AreaCalculator
            AreaCalculator calculator = new AreaCalculator();

            // Calculate area of the square
            double areaSquare = calculator.CalculateArea(sideLength);

            // Display the result
            lblSquareResult.Text = "Area of the square with side length " + sideLength + " is: " + areaSquare;
        }

        protected void ButtonCalculateRectangle_Click(object sender, EventArgs e)
        {
            // Directly use class-level controls
            double length = Convert.ToDouble(txtLength.Text);
            double width = Convert.ToDouble(txtWidth.Text);

            // Create an instance of AreaCalculator
            AreaCalculator calculator = new AreaCalculator();

            // Calculate area of the rectangle
            double areaRectangle = calculator.CalculateArea(length, width);

            // Display the result
            lblRectangleResult.Text = "Area of the rectangle with length " + length + " and width " + width + " is: " + areaRectangle;
        }
    }

    public class AreaCalculator
    {
        // Method to calculate the area of a square
        public double CalculateArea(double sideLength)
        {
            return sideLength * sideLength;
        }

        // Method to calculate the area of a rectangle
        public double CalculateArea(double length, double width)
        {
            return length * width;
        }
    }
}
