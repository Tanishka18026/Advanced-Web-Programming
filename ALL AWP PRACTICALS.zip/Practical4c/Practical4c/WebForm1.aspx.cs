﻿using System;
using System.Web.UI;

namespace Practical4c
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Load the User Control dynamically
            var userControl = Page.LoadControl("~/UserControl(4C).ascx");

            // Use the PlaceHolder control that is already declared in the markup file (WebForm1.aspx)
            PlaceHolder.Controls.Add(userControl);
        }
    }
}
