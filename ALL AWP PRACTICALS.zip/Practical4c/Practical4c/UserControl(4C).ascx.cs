﻿using System;
using System.Web.UI;

namespace Practical4c
{
    public partial class UserControl_4C_ : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // This is where you could add any initialization logic for the User Control.
        }

        protected void ClickMe(object sender, EventArgs e)
        {
            // Change the text, color, and style of the label when the button is clicked
            lb.Text = "Button Clicked";
            lb.ForeColor = System.Drawing.Color.Green;
            lb.Font.Bold = true;
        }
    }
}
