﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

class ADD
{
    int x, y;
    double f;
    string s;

    public ADD(int a, double b)
    {
        x = a;
        f = b;
    }

    public ADD(int a, string b)
    {
        y = a;
        s = b;
    }

    public string Show()
    {
        return "1st constructor (int + double): " + (x + f).ToString();
    }

    public string Show1()
    {
        return "2nd constructor (int + string): " + (y + s);
    }
}

namespace Practical2b3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        TextBox txtInt1, txtFloat, txtInt2, txtString; // Declare TextBox controls
        Label lblResult;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Create and set properties for the input controls
            Label lblIntPrompt = new Label();
            lblIntPrompt.Text = "Enter an integer: ";
            form1.Controls.Add(lblIntPrompt);

            txtInt1 = new TextBox(); // Initialize txtInt1
            txtInt1.ID = "txtInt1";
            form1.Controls.Add(txtInt1);
            form1.Controls.Add(new LiteralControl("<br />"));

            Label lblFloatPrompt = new Label();
            lblFloatPrompt.Text = "Enter a floating-point number: ";
            form1.Controls.Add(lblFloatPrompt);

            txtFloat = new TextBox(); // Initialize txtFloat
            txtFloat.ID = "txtFloat";
            form1.Controls.Add(txtFloat);
            form1.Controls.Add(new LiteralControl("<br />"));

            Label lblInt2Prompt = new Label();
            lblInt2Prompt.Text = "Enter another integer: ";
            form1.Controls.Add(lblInt2Prompt);

            txtInt2 = new TextBox(); // Initialize txtInt2
            txtInt2.ID = "txtInt2";
            form1.Controls.Add(txtInt2);
            form1.Controls.Add(new LiteralControl("<br />"));

            Label lblStringPrompt = new Label();
            lblStringPrompt.Text = "Enter a string: ";
            form1.Controls.Add(lblStringPrompt);

            txtString = new TextBox(); // Initialize txtString
            txtString.ID = "txtString";
            form1.Controls.Add(txtString);
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create and set properties for the Button
            Button cmdShowResults = new Button(); // Button renamed
            cmdShowResults.Text = "Show Results"; // Button text
            cmdShowResults.Click += new EventHandler(cmdShowResults_Click); // Event handler updated
            form1.Controls.Add(cmdShowResults);
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create a Label to display results
            lblResult = new Label(); // Label renamed
            lblResult.ID = "lblResult"; // ID updated
            form1.Controls.Add(lblResult);
        }

        protected void cmdShowResults_Click(object sender, EventArgs e)
        {
            // Get the input values directly from the initialized TextBoxes
            int inputInt1 = System.Convert.ToInt32(txtInt1.Text); // Direct access
            double inputDouble = System.Convert.ToDouble(txtFloat.Text); // Direct access
            int inputInt2 = System.Convert.ToInt32(txtInt2.Text); // Direct access
            string inputString = txtString.Text; // Direct access

            // Use the first constructor (int + double)
            ADD g = new ADD(inputInt1, inputDouble);
            string result1 = g.Show();

            // Use the second constructor (int + string)
            ADD q = new ADD(inputInt2, inputString);
            string result2 = q.Show1();

            // Display the results
            lblResult.Text = result1 + "<br />" + result2; // Displaying results directly
        }
    }

}