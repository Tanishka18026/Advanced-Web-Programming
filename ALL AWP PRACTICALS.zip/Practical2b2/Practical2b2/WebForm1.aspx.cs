﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

// Single Inheritance
class BaseClass1
{
    public string MethodA()
    {
        return "BaseClass1 MethodA";
    }
}

class DerivedClass1 : BaseClass1
{
    public string MethodB()
    {
        return "DerivedClass1 MethodB";
    }
}

// Multilevel Inheritance
class BaseClass2
{
    public string MethodC()
    {
        return "BaseClass2 MethodC";
    }
}

class DerivedClass2 : BaseClass2
{
    public string MethodD()
    {
        return "DerivedClass2 MethodD";
    }
}

class DerivedClass3 : DerivedClass2
{
    public string MethodE()
    {
        return "DerivedClass3 MethodE";
    }
}

// Hierarchical Inheritance
class BaseClass3
{
    public string MethodF()
    {
        return "BaseClass3 MethodF";
    }
}

class DerivedClass4 : BaseClass3
{
    public string MethodG()
    {
        return "DerivedClass4 MethodG";
    }
}

class DerivedClass5 : BaseClass3
{
    public string MethodH()
    {
        return "DerivedClass5 MethodH";
    }
}

// Multiple Inheritance through Interfaces
interface Interface1
{
    string MethodI();
}

interface Interface2
{
    string MethodJ();
}

class DerivedClass6 : Interface1, Interface2
{
    public string MethodI()
    {
        return "DerivedClass6 MethodI (Interface1)";
    }

    public string MethodJ()
    {
        return "DerivedClass6 MethodJ (Interface2)";
    }
}

public partial class WebForm1 : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // Create and set up buttons for each inheritance example
        CreateButton("Single Inheritance", "ButtonSingle", ButtonSingle_Click);
        CreateButton("Multilevel Inheritance", "ButtonMultilevel", ButtonMultilevel_Click);
        CreateButton("Hierarchical Inheritance", "ButtonHierarchical", ButtonHierarchical_Click);
        CreateButton("Multiple Inheritance", "ButtonMultiple", ButtonMultiple_Click);
    }

    private void CreateButton(string text, string id, EventHandler clickEvent)
    {
        Button button = new Button();
        button.ID = id;
        button.Text = text;
        button.Click += clickEvent;
        form1.Controls.Add(button);
        form1.Controls.Add(new LiteralControl("<br /><br />"));

        // Create and add label for output below the button
        Label lblOutput = new Label();
        lblOutput.ID = id + "OutputLabel"; // Unique ID for each output label
        form1.Controls.Add(lblOutput);
        form1.Controls.Add(new LiteralControl("<br />")); // Add space between buttons and labels
    }

    protected void ButtonSingle_Click(object sender, EventArgs e)
    {
        DerivedClass1 obj1 = new DerivedClass1();
        string output = "";  // Capture output

        output += obj1.MethodA() + "<br />";  // Direct method output
        output += obj1.MethodB() + "<br />";

        Label lblSingleOutput = (Label)form1.FindControl("ButtonSingleOutputLabel");
        lblSingleOutput.Text = output;  // Display output in the specific label
    }

    protected void ButtonMultilevel_Click(object sender, EventArgs e)
    {
        DerivedClass3 obj2 = new DerivedClass3();
        string output = "";  // Capture output

        output += obj2.MethodC() + "<br />";  // Direct method output
        output += obj2.MethodD() + "<br />";
        output += obj2.MethodE() + "<br />";

        Label lblMultilevelOutput = (Label)form1.FindControl("ButtonMultilevelOutputLabel");
        lblMultilevelOutput.Text = output;  // Display output in the specific label
    }

    protected void ButtonHierarchical_Click(object sender, EventArgs e)
    {
        string output = "";

        DerivedClass4 obj3 = new DerivedClass4();
        output += obj3.MethodF() + "<br />";  // Direct method output
        output += obj3.MethodG() + "<br />";

        DerivedClass5 obj4 = new DerivedClass5();
        output += obj4.MethodF() + "<br />";  // Direct method output
        output += obj4.MethodH() + "<br />";

        Label lblHierarchicalOutput = (Label)form1.FindControl("ButtonHierarchicalOutputLabel");
        lblHierarchicalOutput.Text = output;  // Display output in the specific label
    }

    protected void ButtonMultiple_Click(object sender, EventArgs e)
    {
        DerivedClass6 obj5 = new DerivedClass6();
        string output = "";

        output += obj5.MethodI() + "<br />";  // Direct method output
        output += obj5.MethodJ() + "<br />";

        Label lblMultipleOutput = (Label)form1.FindControl("ButtonMultipleOutputLabel");
        lblMultipleOutput.Text = output;  // Display output in the specific label
    }
}
