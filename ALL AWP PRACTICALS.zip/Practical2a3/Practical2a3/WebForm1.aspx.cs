﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical2a3
{
    public partial class WebForm1 : Page
    {
        // Declare controls
        Label lblEquation, lblA, lblB, lblC, lblResult;
        TextBox txtA, txtB, txtC;
        Button cmdSolve;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Create and configure labels and controls

            lblEquation = new Label();
            lblEquation.ID = "lblEquation";
            lblEquation.Text = "Enter the coefficients (a, b, c) for ax^2 + bx + c = 0:";
            form1.Controls.Add(lblEquation);
            form1.Controls.Add(new LiteralControl("<br />"));

            lblA = new Label();
            lblA.ID = "lblA";
            lblA.Text = "Enter a: ";
            form1.Controls.Add(lblA);

            txtA = new TextBox();
            txtA.ID = "txtA";
            form1.Controls.Add(txtA);
            form1.Controls.Add(new LiteralControl("<br />"));

            lblB = new Label();
            lblB.ID = "lblB";
            lblB.Text = "Enter b: ";
            form1.Controls.Add(lblB);

            txtB = new TextBox();
            txtB.ID = "txtB";
            form1.Controls.Add(txtB);
            form1.Controls.Add(new LiteralControl("<br />"));

            lblC = new Label();
            lblC.ID = "lblC";
            lblC.Text = "Enter c: ";
            form1.Controls.Add(lblC);

            txtC = new TextBox();
            txtC.ID = "txtC";
            form1.Controls.Add(txtC);
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            cmdSolve = new Button();
            cmdSolve.ID = "cmdSolve";
            cmdSolve.Text = "Solve Quadratic Equation";
            cmdSolve.Click += new EventHandler(cmdSolve_Click);
            form1.Controls.Add(cmdSolve);
            form1.Controls.Add(new LiteralControl("<br /><br />"));

            lblResult = new Label();
            lblResult.ID = "lblResult";
            form1.Controls.Add(lblResult);
        }

        protected void cmdSolve_Click(object sender, EventArgs e)
        {
            // Collect inputs
            double a, b, c;

            if (double.TryParse(txtA.Text, out a) &&
                double.TryParse(txtB.Text, out b) &&
                double.TryParse(txtC.Text, out c))
            {
                // Create an instance of QuadraticEquationSolver
                QuadraticEquationSolver solver = new QuadraticEquationSolver();

                // Use the solver to find the roots of the quadratic equation
                string result = solver.SolveQuadratic(a, b, c);

                // Display the result
                lblResult.Text = result;
            }
            else
            {
                lblResult.Text = "Please enter valid numeric values for a, b, and c.";
            }
        }
    }

    public class QuadraticEquationSolver
    {
        public string SolveQuadratic(double a, double b, double c)
        {
            // Calculate discriminant
            double discriminant = b * b - 4 * a * c;
            string result = "";

            if (discriminant > 0)
            {
                // Two real roots
                double root1 = (-b + Math.Sqrt(discriminant)) / (2 * a);
                double root2 = (-b - Math.Sqrt(discriminant)) / (2 * a);
                result = "Roots are real and distinct:<br/>Root 1 = " + root1 + "<br/>Root 2 = " + root2;
            }
            else if (discriminant == 0)
            {
                // One real root (discriminant is zero)
                double root = -b / (2 * a);
                result = "Roots are real and equal:<br/>Root = " + root;
            }
            else
            {
                // Complex roots (discriminant is negative)
                double realPart = -b / (2 * a);
                double imaginaryPart = Math.Sqrt(-discriminant) / (2 * a);
                result = "Roots are complex:<br/>Root 1 = " + realPart + " + " + imaginaryPart + "i<br/>Root 2 = " + realPart + " - " + imaginaryPart + "i";
            }

            return result;
        }
    }
}
