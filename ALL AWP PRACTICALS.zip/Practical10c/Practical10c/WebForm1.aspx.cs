﻿using System;
using System.Web.UI;
using AjaxControlToolkit;

public partial class Default : Page
{
    TextBox txtSearch;
    Button cmdSearch;
    Label lblTime;
    UpdatePanel updatePanel;
    Timer timer;

    protected void Page_Load(object sender, EventArgs e)
    {
        // Initialize UpdatePanel
        updatePanel = new UpdatePanel();
        updatePanel.ID = "updatePanel";
        updatePanel.UpdateMode = UpdatePanelUpdateMode.Conditional;
        this.Form.Controls.Add(updatePanel);

        // Initialize Label for displaying time
        lblTime = new Label();
        lblTime.ID = "lblTime";
        lblTime.Text = DateTime.Now.ToString();
        updatePanel.ContentTemplateContainer.Controls.Add(lblTime);

        // Initialize Timer for updating the time
        timer = new Timer();
        timer.ID = "timer";
        timer.Interval = 5000; // Update every 5 seconds
        timer.Tick += Timer_Tick;
        updatePanel.ContentTemplateContainer.Controls.Add(timer);

        // Add a LiteralControl for line break
        updatePanel.ContentTemplateContainer.Controls.Add(new LiteralControl("<br/>"));

        // Initialize TextBox for search
        txtSearch = new TextBox();
        txtSearch.ID = "txtSearch";
        updatePanel.ContentTemplateContainer.Controls.Add(txtSearch);

        // Initialize Button for search
        cmdSearch = new Button();
        cmdSearch.ID = "cmdSearch";
        cmdSearch.Text = "Search";
        cmdSearch.Click += CmdSearch_Click;
        updatePanel.ContentTemplateContainer.Controls.Add(cmdSearch);

        // Initialize AutoCompleteExtender for search
        AutoCompleteExtender autoComplete = new AutoCompleteExtender();
        autoComplete.ID = "autoComplete";
        autoComplete.TargetControlID = txtSearch.ID;
        autoComplete.ServiceMethod = "GetSuggestions";
        autoComplete.MinimumPrefixLength = 1;
        autoComplete.CompletionSetCount = 10;
        updatePanel.ContentTemplateContainer.Controls.Add(autoComplete);
    }

    protected void Timer_Tick(object sender, EventArgs e)
    {
        lblTime.Text = DateTime.Now.ToString();
    }

    protected void CmdSearch_Click(object sender, EventArgs e)
    {
        // Logic to handle search
    }

    [System.Web.Services.WebMethod]
    public static string[] GetSuggestions(string prefixText, int count)
    {
        // Return a list of suggestions (you can replace this with a DB call)
        string[] suggestions = { "Apple", "Banana", "Cherry", "Date", "Elderberry", "Fig", "Grape", "Honeydew" };
        return Array.FindAll(suggestions, s => s.StartsWith(prefixText, StringComparison.InvariantCultureIgnoreCase));
    }
}
