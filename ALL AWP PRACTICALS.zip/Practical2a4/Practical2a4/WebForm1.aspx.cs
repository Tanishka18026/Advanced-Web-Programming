﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical2a4
{
    public partial class WebForm1 : Page
    {
        // Declare controls
        Label lblConversionType, lblInput, lblResult;
        RadioButtonList rblConversionType;
        TextBox txtInput;
        Button cmdConvert;

        protected void Page_Load(object sender, EventArgs e)
        {
            // Create and configure label for conversion type selection
            lblConversionType = new Label();
            lblConversionType.Text = "Select conversion type (C for Celsius to Fahrenheit, F for Fahrenheit to Celsius): ";
            form1.Controls.Add(lblConversionType);

            // Create and configure RadioButtonList for conversion type
            rblConversionType = new RadioButtonList();
            rblConversionType.ID = "rblConversionType";
            rblConversionType.Items.Add(new ListItem("Celsius to Fahrenheit", "C"));
            rblConversionType.Items.Add(new ListItem("Fahrenheit to Celsius", "F"));
            form1.Controls.Add(rblConversionType);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create and configure label for input temperature
            lblInput = new Label();
            lblInput.Text = "Enter temperature: ";
            form1.Controls.Add(lblInput);

            // Create and configure TextBox for input temperature
            txtInput = new TextBox();
            txtInput.ID = "txtInput";
            form1.Controls.Add(txtInput);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create and configure Button for conversion
            cmdConvert = new Button();
            cmdConvert.Text = "Convert";
            cmdConvert.Click += new EventHandler(ConvertTemperature);
            form1.Controls.Add(cmdConvert);

            form1.Controls.Add(new LiteralControl("<br /><br />"));

            // Create and configure label for displaying result
            lblResult = new Label();
            lblResult.ID = "lblResult";
            form1.Controls.Add(lblResult);
        }

        protected void ConvertTemperature(object sender, EventArgs e)
        {
            // Find controls by ID
            rblConversionType = (RadioButtonList)form1.FindControl("rblConversionType");
            txtInput = (TextBox)form1.FindControl("txtInput");
            lblResult = (Label)form1.FindControl("lblResult");

            float inputTemp = float.Parse(txtInput.Text);
            TemperatureConverter converter = new TemperatureConverter();
            float convertedTemp;

            if (rblConversionType.SelectedValue == "C")
            {
                convertedTemp = converter.CelsiusToFahrenheit(inputTemp);
                lblResult.Text = "Temperature in Fahrenheit: " + convertedTemp;
            }
            else if (rblConversionType.SelectedValue == "F")
            {
                convertedTemp = converter.FahrenheitToCelsius(inputTemp);
                lblResult.Text = "Temperature in Celsius: " + convertedTemp;
            }
        }
    }

    public class TemperatureConverter  
    {
        private float _celsius;
        private float _fahrenheit;

        public float CelsiusToFahrenheit(float celsius)
        {
            _celsius = celsius;
            _fahrenheit = (_celsius * 9.0f / 5.0f) + 32.0f;
            return _fahrenheit;
        }

        public float FahrenheitToCelsius(float fahrenheit)
        {
            _fahrenheit = fahrenheit;
            _celsius = (_fahrenheit - 32) * (5.0f / 9.0f);
            return _celsius;
        }
    }
}
     