﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical9c
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindGrid();
            }
        }

        private void BindGrid()
        {
            // Define the connection string directly here
            string connectionString = "Data Source=localhost\\SQLExpress;Initial Catalog=EmployeeDB;Integrated Security=True";
            string query = "SELECT empID, empName, empCity, empSalary FROM Employee";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    GridView gridView = new GridView
                    {
                        AutoGenerateColumns = false
                    };

                    // Create BoundField for empID
                    BoundField empIdField = new BoundField
                    {
                        DataField = "empID",
                        HeaderText = "Employee ID"
                    };
                    gridView.Columns.Add(empIdField);

                    // Create BoundField for empName
                    BoundField empNameField = new BoundField
                    {
                        DataField = "empName",
                        HeaderText = "Employee Name"
                    };
                    gridView.Columns.Add(empNameField);

                    // Create BoundField for empCity
                    BoundField empCityField = new BoundField
                    {
                        DataField = "empCity",
                        HeaderText = "Employee City"
                    };
                    gridView.Columns.Add(empCityField);

                    // Create BoundField for empSalary
                    BoundField empSalaryField = new BoundField
                    {
                        DataField = "empSalary",
                        HeaderText = "Employee Salary"
                    };
                    gridView.Columns.Add(empSalaryField);

                    // Bind the data to the GridView
                    gridView.DataSource = dt;
                    gridView.DataBind();

                    // Add GridView to the page
                    form1.Controls.Add(gridView);
                }
            }
        }
    }
}
