﻿using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//using System.Web.UI;
using System.Web.UI.WebControls;

namespace Practical1e
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        Literal ltr;
        Label lb1, lb2, lb3, lb4, lb5, lb6;
        TextBox tb1, tb2;
        Button bt1, bt2, bt3, bt4;

        protected void Page_Load(object sender, EventArgs e)
        {

            lb1 = new Label();
            lb1.Text = "Num 1:";
            this.form1.Controls.Add(lb1);

            tb1 = new TextBox();
            form1.Controls.Add(tb1);
            ltr = new Literal();
            ltr.Text = "</br>";
            this.form1.Controls.Add(ltr);

            lb2 = new Label();
            lb2.Text = "Num 2:";
            this.form1.Controls.Add(lb2);

            tb2 = new TextBox();
            form1.Controls.Add(tb2);
            ltr = new Literal();
            ltr.Text = "</br>";
            this.form1.Controls.Add(ltr);

            bt1 = new Button();
            bt1.Text = "Add";
            bt1.Click += bt1_Click;
            this.form1.Controls.Add(bt1);

            lb3 = new Label();
            lb3.Text = " ";
            this.form1.Controls.Add(lb3);
            ltr = new Literal();
            ltr.Text = "</br>";
            this.form1.Controls.Add(ltr);

            bt2 = new Button();
            bt2.Text = "Sub";
            bt2.Click += bt2_Click;
            this.form1.Controls.Add(bt2);


            lb4 = new Label();
            lb4.Text = " ";
            this.form1.Controls.Add(lb4);
            ltr = new Literal();
            ltr.Text = "</br>";
            this.form1.Controls.Add(ltr);

            bt3 = new Button();
            bt3.Text = "Multiply";
            bt3.Click += bt3_Click;
            this.form1.Controls.Add(bt3);


            lb5 = new Label();
            lb5.Text = " ";
            this.form1.Controls.Add(lb5);
            ltr = new Literal();
            ltr.Text = "</br>";
            this.form1.Controls.Add(ltr);

            bt4 = new Button();
            bt4.Text = "Divided";
            bt4.Click += bt4_Click;
            this.form1.Controls.Add(bt4);

            lb6 = new Label();
            lb6.Text = " ";
            this.form1.Controls.Add(lb6);



        }
        protected void bt1_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(tb1.Text);
            int num2 = int.Parse(tb2.Text);
            int add = num1 + num2;
            lb3.Text = "Addition=" + add;
        }

        protected void bt2_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(tb1.Text);
            int num2 = int.Parse(tb2.Text);
            int sub = num1 - num2;
            lb4.Text = "subraction=" + sub;
        }

        protected void bt3_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(tb1.Text);
            int num2 = int.Parse(tb2.Text);
            int mul = num1 * num2;
            lb5.Text = "Multiplication=" + mul;
        }

        protected void bt4_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(tb1.Text);
            int num2 = Convert.ToInt32(tb2.Text);
            int div = num1 / num2;
            lb6.Text = "Division=" + div;
        }

    }
}